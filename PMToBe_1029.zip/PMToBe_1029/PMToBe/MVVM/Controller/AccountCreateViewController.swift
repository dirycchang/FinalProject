//
//  AccountCreateViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/28.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class AccountCreateViewController: UIViewController,UITextFieldDelegate{
    
    
    @IBAction func btn立刻登入_Click(_ sender: Any) {
        
        let LoginVC:LoginViewController = self.storyboard?.instantiateViewController(withIdentifier: "login") as! LoginViewController
        self.present(LoginVC, animated: true, completion: nil)
    }
    //////寫入firebase
    var ref:DatabaseReference? = nil
    var myGender:String = ""
    var myCharacter:String = ""
    
    
    @IBOutlet weak var lbl信箱: UILabel!
    @IBOutlet weak var txt信箱: UITextField!
  
    @IBOutlet weak var lbl帳號: UILabel!
    @IBOutlet weak var lbl密碼: UILabel!
    @IBOutlet weak var lbl姓名: UILabel!
    @IBOutlet weak var lbl性別: UILabel!
    @IBOutlet weak var txt帳號: UITextField!
    @IBOutlet weak var txt密碼: UITextField!
    @IBOutlet weak var txt姓名: UITextField!

    
    @IBAction func seg性別_ValueChanged(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{
            if let gender = sender.titleForSegment(at: 0){
                myGender = gender
                print(myGender)
            }
        }else if sender.selectedSegmentIndex == 1{
            if let gender = sender.titleForSegment(at: 1){
                myGender = gender
                print(myGender)
            }
        }
        
    }
    
//    @IBAction func seg角色_ValueChanged(_ sender: UISegmentedControl) {
//
//        if sender.selectedSegmentIndex == 0{
//            if let character = sender.titleForSegment(at: 0){
//                myCharacter = character
//                print(myCharacter)
//            }
//        }else if sender.selectedSegmentIndex == 1{
//            if let character = sender.titleForSegment(at: 1){
//                myCharacter = character
//                print(myCharacter)
//            }
//        }else if sender.selectedSegmentIndex == 2{
//            if let character = sender.titleForSegment(at: 2){
//                myCharacter = character
//                print(myCharacter)
//            }
//        }
//    }
    
    
    //寫入資料庫
    @IBAction func btn完成_Selected(_ sender: UIButton) {
        
        
        
        let postdata:[String: Any] = ["USername":"\(txt帳號.text as! String)","Name":"\(txt姓名.text as! String)","Email":"\(txt信箱.text as! String)","Password":"\(txt密碼.text as! String)","Gender":"\(myGender)"]
        
        let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/register")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "POST"
        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
        request.httpBody = httpbody
        
        
        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            if let response = response{
                print(response)
            }
            
            if let data = data{ //body裡面的東西
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                    print(json)
                    
                    
                    if let result = json["result"] as? Int{

                        if result == 1{
                            
                       DispatchQueue.main.async {
                                self.txt密碼.resignFirstResponder()
                                self.txt帳號.resignFirstResponder()
                                self.txt姓名.resignFirstResponder()
                                self.txt信箱.resignFirstResponder()
                                
                                self.view.resignFirstResponder()
                                
                                let alertView = UIAlertController.init(title: "註冊成功！", message: "", preferredStyle: .alert)
                                alertView.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
                                self.present(alertView, animated: true, completion: nil)
                                
                                // 呈現主視圖
                                if let viewController = self.storyboard?.instantiateViewController(withIdentifier: "login") {
                                    UIApplication.shared.keyWindow?.rootViewController = viewController
                                    self.dismiss(animated: true, completion: nil)
                                }
                            }
                        }else{
                            print("登入失敗")
                        }
                    }
                    
                }catch{
                    print(error)
                }
            }
        })
        dataTask.resume()
    }
    
    ///////////
//    //pickerView要顯示的地區陣列
//    let districtArray = ["台北","桃園","新竹","苗栗","台中","彰化","雲林","嘉義","台南","高雄","屏東","宜蘭","花蓮","台東"]
    

    
    @IBOutlet weak var myPickerView: UIPickerView!
    
//    @IBAction func district_Click(_ sender: Any) {
//        myDistrict.resignFirstResponder()
//        myPickerView.isHidden = false
//
//    }
    
    
//    func numberOfComponents(in pickerView: UIPickerView) -> Int {
//        return 1 //會有2個選項（2個component 其index值為0,1 ）
//    }
//
//    //實作pickerView方法：回傳每個類別中 有多少選項
//    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
//        return districtArray.count
//    }
//
//    //實作pickerView方法：回傳字串（要顯示的文字）
//    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?{
//
//        return districtArray[row]
//
//    }
    
//    //實作pickerView實作：當使用者波動選單 didSelectRow選到什麼選項後  就執行此方法
//    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
//        myDistrict.text = districtArray[row]
//        myPickerView.isHidden = true
//
//
//    }
    

    
    //當文字開始編輯 要讓整個view往上移
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0 //先宣告位移植
        
        //因所有textField都共用同一個協定  所以要用tag判斷是哪的textField被編輯
        if textField.tag == 3{
            shift = 90.0
        }else if textField.tag == 4{
            shift = 120.0
        }
        
        //讓view往上移動（x軸不動, y軸減少） 註：y軸往上為正 往下為負
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y - shift)
    }
    
    
    
    //結束編輯：把view往下移回來
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0 //先宣告位移植
        
        //因所有textField都共用同一個協定  所以要用tag判斷是哪的textField被編輯
        if textField.tag == 3{
            shift = 90.0
        }else if textField.tag == 4{
            shift = 120.0
        }
        
        //讓view往下移動（x軸不動, y軸加回來）
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y + shift)
    }
    
    //狀態1：按下去接觸到螢幕的瞬間:收鍵盤
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        txt姓名.resignFirstResponder()
        txt信箱.resignFirstResponder()
        txt帳號.resignFirstResponder()
        txt密碼.resignFirstResponder()
    }
    
    //狀態2： 按到且滑動時
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    //狀態3：手指離開螢幕的瞬間
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    //狀態4：觸控事件被中斷 ex：有電話打來
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        //移動TextField跟PickerView都要Delegate
//        txt帳號.delegate = self
//        txt密碼.delegate = self


        
        
//        Auth.auth().signIn { (user, error) in
//            if let error = error{
//                print(error.localizedDescription)
//            }
//        }
        
        //連接資料庫的節點
        ref = Database.database().reference().child("users")
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
