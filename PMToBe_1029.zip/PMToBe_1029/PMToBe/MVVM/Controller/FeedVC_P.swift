//
//  FeedVC_P.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit
import Speech


class FeedVC_P: UIViewController,UITableViewDataSource, UITableViewDelegate,UISearchResultsUpdating,SFSpeechRecognizerDelegate, SFSpeechRecognitionTaskDelegate{
    
    // 語音識別對象,這裏直接給出識別語言(繁體中文)
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "zh_TW"))!
    // 識別請求
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    // 識別任務
    private var recognitionTask: SFSpeechRecognitionTask?
    // 設備音頻
    private let audioSession = AVAudioSession.sharedInstance()
    // 聲音輸入引擎
    private let audioEngine = AVAudioEngine()
    // 麥克風按鈕是否可點，取決於用户權限
    private var micButtonEnabled = false
    // 語音識別結果
    private var recordResult:String = ""
    // 説話間隔時間
    private var timer:Timer!
    
    var myWords = [pStruct]() //篩選模仿結構
    
    var searchController: UISearchController!
//    var hidesSearchBarWhenScrolling: Bool!
    
    var searchAdv = [pStruct]() //篩選模仿結構
    var searchResults = [String]()
    
    var strDataPName:Data?
    var strDataMName:Data?
    var strDataP_pic:Data?
    var strDataM_pic:Data?
    
    
    var getFilterResult:[String] = [String]()
    var pName:[String] = [] //攝影師姓名
    var mName:[String] = [] //模特兒姓名
    var profile_P:[String] = [] //攝影師大頭照
    var profile_M:[String] = [] //模特兒大頭照
    var pId:[String] = [] //攝影師Id
    var mId:[String] = [] //模特兒Id
    
    
    var myCharacter:String = ""
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchString = searchController.searchBar.text!
        searchAdv = moviesArray.filter { (myStruct) -> Bool in
            return myStruct.Location.contains(searchString) || myStruct.ShowName.contains(searchString) || myStruct.PhotoType.contains(searchString)
        }
        tableView.reloadData()
    }
    
    @IBAction func btn語音_Click(_ sender: UIBarButtonItem) {
        startRecording()
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    private let cellID = "cellID"
    private var moviesArray = [pStruct]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    let service = Service_P()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        myCharacter = "攝影師"
        appDelegate.strChooseCharacter = myCharacter
 
        tableView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tableView.register(Cell_P.self, forCellReuseIdentifier: cellID)
        tableView.contentInset = UIEdgeInsets(top: 22, left: 0, bottom: 0, right: 0)
        getMovies(fromService: service)
        
        navigationController?.navigationBar.prefersLargeTitles = true
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        navigationItem.searchController = searchController
        searchController.searchBar.placeholder = "以姓名、風格、地區來篩選"
        searchController.searchBar.searchBarStyle = .minimal
        searchController.searchBar.barTintColor = .white
//        tableView.tableHeaderView = searchController.searchBar
        definesPresentationContext = true
        navigationItem.hidesSearchBarWhenScrolling = false//讓searchbar固定顯示在畫面上
        navigationController?.navigationBar.prefersLargeTitles = false
        
        speechRecognizer.delegate = self
        // 語音識別權限請求
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            switch authStatus {
            case .authorized:
                // 通過授權
                self.micButtonEnabled = true
                break
            case .denied:
                // 拒絕授權
                self.micButtonEnabled = false
                break
            case .restricted:
                // 權限受限制
                self.micButtonEnabled = false
                break
            case .notDetermined:
                // 權限不明確
                self.micButtonEnabled = false
                break
            }
        }

    }
    
    // 這裏就會出現一個問題，比如説用户同意了語音識別權限，麥克風按鈕可點，返回桌面進入設置，找到本應用，關閉語音識別權限，然後再進入app，發現麥克風按鈕還是可點的，這就尷尬啦，所以頁面出現時還要判斷當前權限
    override func viewWillAppear(_ animated: Bool) {
        // 獲取當前語音識別權限
        AVAudioSession.sharedInstance().requestRecordPermission { (permiss:Bool) in
            self.micButtonEnabled = permiss
        }
    }
    
    // 開始語音識別（這是我們自己寫的方法，在麥克風按鈕事件中調用這個函數）
    func startRecording(){
        // 判斷音聲引擎是否在運行
        if !audioEngine.isRunning {
            recordResult = "" // 接收識別結果的String賦為空
            recording()
        }
    }
    
    // 語音識別終止
    func stopRecording(){
        if (recognitionRequest != nil) {
            recognitionRequest?.endAudio()
        }
    }
    
    // 語音識別詳細內容
    func recording() {
        // 判斷目前有無識別任務，取消之前所有任務
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        do {
            // 設置設備音頻
            try audioSession.setCategory(AVAudioSessionCategoryRecord) // 將音頻設置為錄音
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        // 初始化識別請求
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true
        // 登機語音識別任務
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest, delegate: self)
        
        // 麥克風獲取語音片斷
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        // 追加後續輸入的語音
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        audioEngine.prepare()
        do {
            // 開始錄音
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }
    }
    
    /******* 以下都是代理方法 *******/
    
    // 判斷當前是否連接網絡
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        // 這裏有兩點不足，1：只有關閉或打開網絡的操作時這個函數才執行，如果我一直不改變網絡狀態，這個函數等於沒用。假設我點擊語音按鈕時判斷available是否為true，false時彈出alert提示沒網，那麼設備沒聯網的狀態下打開app且不改變網絡狀態，點擊語音按鈕就不會提示，這就需要程序員自己判斷了。2：這個函數判斷不了當前連接的網絡是否有效，比如連了一個無效的wifi，available還是為true
    }
    
    // 錄音過程中獲取到聲音
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didHypothesizeTranscription transcription: SFTranscription) {
        // 這個代理方法非常重要，錄音過程中檢測到聲音就會執行，比如説了話之後讓他自動結束語音，就可以在此加上計時器timer。
        if(timer != nil && timer.isValid){
            timer.invalidate()
            timer = nil
        }
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true, block: { (Timer) in
            self.stopRecording()
        })
        //只要在説話，計時器就不會走，停止説話計時器開始走，停止2兩秒不説話，則錄音就會自動結束開始識別成文本，時間可以自己設置
    }
    
    // 開始識別語音
    func speechRecognitionTaskFinishedReadingAudio(_ task: SFSpeechRecognitionTask) {
        // 將聲音轉成文本，這個函數裏面可以什麼都不用寫
    }
    
    // 錄音結束之後的識別處理
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishRecognition recognitionResult: SFSpeechRecognitionResult) {
        print(recognitionResult) // 輸出的是一個數組，裏面是所有識別出來的結果
        recordResult = recognitionResult.bestTranscription.formattedString // 獲取最優的結果，這裏看情況，不一定是你需要的那個，也可以做一個tableView，讓用户自己選結果
    }
    
    // 語音轉文本結束
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishSuccessfully successfully: Bool) {
        // 語音識別結束後，在這裏釋放對象
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        self.recognitionRequest = nil
        self.recognitionTask = nil
        do {
            // 添加這個代碼是因為涉及到文本轉語音的需求。語音識別會讓音頻處於錄音狀態，這個時候要朗讀文本的話根本沒有聲音，所以需要添加這個設置。
            try audioSession.setCategory(AVAudioSessionCategoryAmbient)
        }catch let error as NSError{
            print(error.code)
        }
        if(timer != nil){
            timer.invalidate()
            timer = nil
        }
        // 在這裏，大家拿到了recordResult，就可以做想做的事啦
        
        
    }
    
    
    private func getMovies<S: Gettable_P>(fromService service: S) where S.T == Array<pStruct?> {
        
        service.get { [weak self] (result) in
            switch result {
            case .Success(let movies):
                var tempMovies = [pStruct]()
                for movie in movies {
                    if let movie = movie {
                        tempMovies.append(movie)
                    }
                }
                self?.moviesArray = tempMovies
            //dump(self.movies)
            case .Error(let error):
                print(error)
            }
        }
    }
    
//    func dummyMovie() {
//        let dummyMovie = pStruct(UserId: 1, UserName: "test", ShowName: "test1", ProfileUrl: "111", PhotoType: "1", Location: "1", Introduction: "2", AcceptStyle: "1", Gender: "1", Phone: "1")
//        moviesArray.append(dummyMovie)
//    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID) as! Cell_P
//        let movie = moviesArray[indexPath.row]
//        let movieViewModel = ViewModel_P(model: movie)
        
        if navigationItem.searchController?.isActive == true {
            let movie = searchAdv[indexPath.row]
            let movieViewModel = ViewModel_P(model: movie)
            cell.displayMovieInCell(using: movieViewModel)
        } else {
            let movie = moviesArray[indexPath.row]
            let movieViewModel = ViewModel_P(model: movie)
            cell.displayMovieInCell(using: movieViewModel)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if navigationItem.searchController?.isActive == true {
            return searchAdv.count
        } else {
            return moviesArray.count
        }

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    //點擊儲存格
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        var loadID:String = ""
        //點擊儲存格
        if myCharacter == "攝影師"{
            
            print(indexPath.row) //TableView第幾列
            print("==pId==",pId)

            let myVCDetail: DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc詳細資訊") as! DetailViewController
            //                myVCDetail.infofromViewOne = appDelegate.strName[indexPath.row]
            if navigationItem.searchController?.isActive == true {
                //若有用Search Bar來搜尋 就用searchAdv
                myVCDetail.p_id = searchAdv[indexPath.row].UserId //將攝影師Id傳過去
                myVCDetail.p_name = searchAdv[indexPath.row].ShowName
                myVCDetail.p_style = searchAdv[indexPath.row].PhotoType //將攝影師風格傳過去
                myVCDetail.p_location = searchAdv[indexPath.row].Location
                myVCDetail.p_phone = searchAdv[indexPath.row].Phone
                myVCDetail.p_Email = searchAdv[indexPath.row].Email
            } else {
                //若沒用Search Bar來搜尋 就用原來的moviesArray
                myVCDetail.p_id = moviesArray[indexPath.row].UserId //將攝影師Id傳過去
                myVCDetail.p_name = moviesArray[indexPath.row].ShowName
                myVCDetail.p_style = moviesArray[indexPath.row].PhotoType //將攝影師風格傳過去
                myVCDetail.p_location = moviesArray[indexPath.row].Location
                myVCDetail.p_phone = moviesArray[indexPath.row].Phone
                myVCDetail.p_Email = moviesArray[indexPath.row].Email
                
            }
            
            
            self.navigationController?.show(myVCDetail, sender: nil)
            
        }
    }

}
