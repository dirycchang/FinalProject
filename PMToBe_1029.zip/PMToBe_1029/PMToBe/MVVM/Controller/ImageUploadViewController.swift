//
//  ImageUploadViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/9/5.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth
import FirebaseDatabase

class ImageUploadViewController: UIViewController, UIImagePickerControllerDelegate,UINavigationControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    let apiFactory = APIFactory()
    var pPicArray:[String] = [] //攝影師作品
    var mPicArray:[String] = [] //模特兒作品
    var strDataPpic:Data? //攝影師作品Data
    var strDataMpic:Data? //模特兒作品Data
    var strData_P:Data? //攝影師所有資料
    var strData_M:Data? //模特兒所有資料
    var pId:[String] = [] //攝影師Id
    var mId:[String] = [] //模特兒Id
    
    @IBOutlet weak var sharedImagesCollection: UICollectionView!
    @IBOutlet weak var uploadStatus: UIProgressView!
    
    

    //服從UICollectionViewDelegate 與 UICollectionViewDataSource 要實作以下兩個方法
    //有幾個cell
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        let nameCount:Int = 0
        
        if appDelegate.strChooseCharacter == "攝影師"{
            return pPicArray.count
        }else if appDelegate.strChooseCharacter == "模特兒"{
            return mPicArray.count
        }
        
        return nameCount
    }
    
    //顯示cell內容的作法：從link下載data後 再改為image
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = sharedImagesCollection.dequeueReusableCell(withReuseIdentifier: "myCell", for: indexPath) as! ImageCollectionViewCell
        
 
        if appDelegate.strChooseCharacter == "攝影師"{

            if let url = URL(string:pPicArray[indexPath.row]){
                let downloadTask = URLSession.shared.dataTask(with: url){
                    (data,response,error) in
                    guard let imageData = data else {return} //將data指定給imageData 就繼續往下執行 否則return
                    OperationQueue.main.addOperation{
                        guard let image = UIImage(data: imageData) else {return} //將imageData轉為UIImage 就繼續往下執行 否則return
                        //加圖片至快取
                        cell.image.image = image
                        CacheManager.shared.cache(object: image, key: self.pPicArray[indexPath.row])
                    }
                }
                downloadTask.resume()
            }
            
        }else if appDelegate.strChooseCharacter == "模特兒"{
            if let url = URL(string:mPicArray[indexPath.row]){
                let downloadTask = URLSession.shared.dataTask(with: url){
                    (data,response,error) in
                    guard let imageData = data else {return}
                    OperationQueue.main.addOperation{
                        guard let image = UIImage(data: imageData) else {return}
                        //加圖片至快取
                        cell.image.image = image
                        CacheManager.shared.cache(object: image, key: self.mPicArray[indexPath.row])
                    }
                }
                downloadTask.resume()
            }
        }
        return cell

        
    }
    


    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let apiFactory = APIFactory()
        sharedImagesCollection.delegate = self
        sharedImagesCollection.dataSource = self
        
        //取得使用者Id
        if let loadId = UserDefaults.standard.value(forKey: "thisId") as? String{
            print("===========這是我ID======")
            print(loadId)
            
            if appDelegate.strChooseCharacter == "攝影師"{
                
                strDataPpic = APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/image?uid=\(loadId)")
                pPicArray = apiFactory.parse_Product(data: strDataPpic!) as! [String]
                
            }else if appDelegate.strChooseCharacter == "模特兒"{
                
                strDataMpic = APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/image?uid=\(loadId)")
                mPicArray = apiFactory.parse_Product(data: strDataMpic!) as! [String]
                
            }
        }
        //取得使用者Name
        if let loadName = UserDefaults.standard.value(forKey: "thisUserName") as? String{
            print("===========這是我Name======")
            print(loadName)
        }
        
     

        // 不顯示進度條
        uploadStatus.isHidden = true
        
        //服從UICollectionViewDelegate, UICollectionViewDatasource
        sharedImagesCollection.delegate = self
        sharedImagesCollection.dataSource = self
        

    
    }
    
    ////照片上傳///////////
    @IBAction func uploadImage_Click(_ sender: UIButton) {
        
        let imagePicker = UIImagePickerController() //建立UIImagePickerController()
        imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary //資料來源：從照片圖庫
        imagePicker.allowsEditing = false //編輯功能關閉
        imagePicker.delegate = self //要服從UIImagePickerControllerDelegate,UINavigationControllerDelegate
        present(imagePicker, animated: true, completion: nil)//呈現
    }
    
    //UIImagePickerControllerDelegate 要實作取得照片後的方法 (會回傳info 裡面包含所有我們需要的東西)
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // 設定儲存位置 存在pic子目錄
        let storageRef = Storage.storage().reference().child("pic")
        
        // 從info中取得選取影像 並轉型為UIImage
        var image:UIImage?
        if let myImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
            image = myImage
        }
        
        // 設定上傳檔案名
        var filename = "image.JPG"
        if let url = info[UIImagePickerControllerImageURL] as? URL{
            filename = url.lastPathComponent //url最後一個Component就是檔案名稱
            print("==這是檔案名稱==",filename)
            UserDefaults.standard.set(filename, forKey: "UPload_fileName")
            UserDefaults.standard.synchronize()
        }
        
        // 取得目前使用者 ID
        if let theUid = UserDefaults.standard.value(forKey: "thisId") as? String{
            if let data = UIImageJPEGRepresentation(image!, 0.1){ //UIImageJPEGRepresentation(設壓縮比)
                
                //建立中介資料
                let myMetadata = StorageMetadata()
                
                myMetadata.contentType = "image/jpeg" //***轉為圖擋
                
                myMetadata.customMetadata = ["myKey":"myValue"] //可自訂metadata 將要的資訊設在Storage中
                
                uploadStatus.isHidden = false //上傳前顯示進度條
                
                //＊＊＊上傳 子目錄：第一層為使用者Id  第二層為檔案名稱  putData上傳檔案
                let task = storageRef.child(theUid).child(filename).putData(data, metadata: myMetadata) { (metadata, error) in //完成時會回傳: 真正完成的metadata跟Error
                    
                    self.uploadStatus.isHidden = true //上傳成功與否 都將進度條隱藏
                    
                    if  error == nil{
                        
                        //若上傳成功
                        let dataRef = Database.database().reference().child("pic")
                        
                        storageRef.child(theUid).child(filename).downloadURL(completion: {
                           
                            (url, error) in

                            if error != nil {
                                
                                return
                            } else {
                                
                                let url = url?.absoluteString //＊＊＊取得URL的字串
                                
                                let value = ["uid":theUid,"link":url]
                                
                                dataRef.childByAutoId().setValue(value)
                                
                                let uploaderID = theUid
                                
                                //寫入Server
                                let newURL = self.apiFactory.postPhotoToDatabase(uploaderId: uploaderID, firebaseURL:url!)
                                
                                print("==最新url==",newURL)
                            }
                        })

                        let firebaseURL = self.appDelegate.strFirebaseURL
                        print("==測試用firebaseURL=",firebaseURL)
    
                    }else{
                        //若上傳失敗 印出錯誤
                        print(error?.localizedDescription)
                    }
                }
                //進度顯示
                task.observe(.progress) { (snapshot) in //observe監聽整個過程 回傳一個snapshot
                    if let theProgress = snapshot.progress?.fractionCompleted{ //fractionCompleted完成百分比
                        self.uploadStatus.progress = Float(theProgress) //轉型為Float
                    }
                }
            }
        }
        picker.dismiss(animated: true, completion: nil) //將picker關閉
    }
    


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
