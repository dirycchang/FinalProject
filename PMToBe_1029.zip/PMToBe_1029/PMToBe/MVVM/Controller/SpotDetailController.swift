//
//  SpotDetailController.swift
//  PMToBe
//
//  Created by Yi Hwei Huang on 2018/10/11.
//  Copyright © 2018 YiChun. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class SpotDetailController: UIViewController, CLLocationManagerDelegate {

    
    @IBOutlet weak var detailMapView: MKMapView!
    @IBOutlet weak var spotImage: UIImageView!
    @IBOutlet weak var lblSpotName: UILabel!
    @IBOutlet weak var lblSpotAddress: UILabel!
    @IBOutlet weak var lblSpotDescri: UILabel!
    
    var strAddress:String=""
    var strDescription:String=""
    var strName:String=""
    var PosX:Double=0.0 //經度 lon
    var PosY:Double=0.0 //緯度 lat
    var strNamestrNamestrName:String=""
    var spotId:Int = 0
    var mapScaleMeter:Double=1000.0
    var strDataPic:Data?
    var spotGUID:String = ""
    var strDataPic2:Data?
    var strpicURL:String = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        let loadId = spotId
        
        
        print("==已傳==",spotId," ",strName," ",PosX," ",PosX," ",strAddress)
        
        strDataPic = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot?id=\(loadId)")
        spotGUID = APIFactory_2().parseGUID(data: strDataPic!) as! String
        
        strDataPic2 = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot/image?lid=\(spotGUID)")
        strpicURL = APIFactory().parsePicURL(data:strDataPic2!) as! String
        
        lblSpotName.text=strName
        lblSpotDescri.text=strDescription
        lblSpotAddress.text=strAddress
        
        if let url = URL(string:strpicURL){
            let downloadTask = URLSession.shared.dataTask(with: url){
                (data,response,error) in
                
                guard let imageData = data else {return} //將data指定給imageData 就繼續往下執行 否則return
                OperationQueue.main.addOperation{
                    guard let image = UIImage(data: imageData) else {return} //將imageData轉為UIImage 就繼續往下執行 否則return
                    //加圖片至快取
                    self.spotImage.image = image
                    self.spotImage.layer.masksToBounds = true
                    self.spotImage.layer.cornerRadius = 5
                    
                    CacheManager.shared.cache(object: image, key: self.strpicURL)
                    
                }
            }
            downloadTask.resume()
        }
        
        
        self.addLandmark()
        
 
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        if animated == true{
            self.spotImage.layer.cornerRadius = self.spotImage.layer.frame.size.width/2
        }
        
    }
    
    func addLandmark(){
        let Lon:Double=Double(PosX) //經度
        let Lat:Double=Double(PosY) //緯度
        
        var myAutoFlag:CLLocationCoordinate2D=CLLocationCoordinate2D()
        myAutoFlag.longitude=Lon
        myAutoFlag.latitude=Lat
        print(myAutoFlag.latitude,"====myAutoFlag.latitude==")
        print(myAutoFlag.longitude,"=======myAutoFlag.longitude======")
        
        
        let myAutoFlagAnno:MKPointAnnotation = MKPointAnnotation()
        myAutoFlagAnno.coordinate=myAutoFlag
        myAutoFlagAnno.title=lblSpotName.text
        print(myAutoFlagAnno.title!,"=====myAutoFlagAnno.title=======")
        
        
        self.detailMapView.addAnnotation(myAutoFlagAnno)
        
        self.mapScaleMeter *= 1.5
        let region:MKCoordinateRegion=MKCoordinateRegionMakeWithDistance(myAutoFlag, self.mapScaleMeter,self.mapScaleMeter )
        print("==region請看==:",region)
        

        self.detailMapView.setRegion(region, animated: false)

        print("==完成加地標1==")
    }
    
    
    
   

}
