//
//  LoginViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/9/11.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,UITextFieldDelegate {

    @IBOutlet weak var myAccount: UITextField!
    
    @IBOutlet weak var myPassword: UITextField!
    
    @IBAction func btn登入_Click(_ sender: Any) {
        
        let postdata:[String: Any] = ["Username":myAccount.text,"Password":myPassword.text]
        
//          let postdata:[String: Any] = ["Username":"Admin","Password":"12345678"]
        
        let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/login")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "POST"
        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
//        guard let httpbody = try? String.data(postdata) else {return}
        request.httpBody = httpbody
        
        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            if let response = response{
                print("這是回應==============:")
                print(response)
            }
            
            if let data = data{ //body裡面的東西
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                    print("以下這是JSON==============:")
                    print(json)
                    print("以下這是result==============:")
                    print(json["result"]!)
                    
                    if let result = json["result"] as? Int{
                        
//                        print("有轉成功")
//
                        if result == 1{
  
                            if let currentId = json["data"] as? [String:Any]{
                                
                                print("=============我有取到data=======")
                                
                                if let myId = currentId["id"] as? Int{
                                    
                                    let loginId = String(myId)
                                    print("===========這是我ID======")
                                    print(loginId)
                                    
                                    DispatchQueue.main.async{
                                        UserDefaults.standard.set(loginId, forKey: "thisId") //用set存進去的可能是任何型別 所以之後要取出要用optional binding
                                        UserDefaults.standard.set(self.myAccount.text, forKey: "thisUserName")
                                        UserDefaults.standard.synchronize() //同步
                                    }
   
                                }
                            }
                            
                            DispatchQueue.main.async {
                                self.myPassword.resignFirstResponder()
                                self.myAccount.resignFirstResponder()
                                self.view.resignFirstResponder()
                                
                                let alertView = UIAlertController.init(title: "成功登入", message: "", preferredStyle: .alert)
                                alertView.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
                                self.present(alertView, animated: true, completion: nil)
                                
                                // 呈現主視圖
                                if let viewController = self.storyboard?.instantiateViewController(withIdentifier: "MainView") {
                                    UIApplication.shared.keyWindow?.rootViewController = viewController
                                    self.dismiss(animated: true, completion: nil)
                                }
                            }
                        }else if result != 1
                        {
                            DispatchQueue.main.async{
                                let alertController = UIAlertController(title: "登入失敗", message: "帳號密碼輸入錯誤，請重新輸入一次", preferredStyle: UIAlertControllerStyle.alert)
                                
                                let cancelAction = UIAlertAction(title: "再試一次", style: UIAlertActionStyle.default, handler: {
                                    (action : UIAlertAction!) -> Void in })
                                
                                alertController.addAction(cancelAction)
                                
                                self.present(alertController, animated: true, completion: nil)
                                print("登入失敗")
                            }
                            
                        }
                    }
                    
                    
                    
                    
                }catch{
                    print("以下這是錯誤==============:")
                    print(error)
                }
            }
        })
        dataTask.resume()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myAccount.delegate = self
        myPassword.delegate = self
        
        // Do any additional setup after loading the view.
    }

    
    @IBAction func btn去註冊_Click(_ sender: Any) {
        
            let AccountCreateVC:AccountCreateViewController = self.storyboard?.instantiateViewController(withIdentifier: "accountcreate") as! AccountCreateViewController
            self.present(AccountCreateVC, animated: true, completion: nil)
    }
    
    //實作UITextFieldDelegate協定的兩個方法：textFieldDidBeginEditing跟textFieldDidEndEditing
    //當文字開始編輯 ：我們要讓虛擬鍵盤不會擋到textField  且不會破壞排版 所以要讓整個view往上移
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0 //先宣告位移植
        
        //因所有textField都共用同一個協定  所以要判斷是哪的textField被編輯: 用tag判斷
        if textField.tag == 1{
            shift = 60.0
        }else if textField.tag == 2{
            shift = 120.0
        }
        
        //讓view移動（x軸不動, y軸減少）  註：y軸往上為正 往下為負  所以要用上就把y值越小越高
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y - shift)
    }
    
    //結束編輯：把view移回來
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0 //先宣告位移植
        
        //因所有textField都共用同一個協定  所以要判斷是哪的textField被編輯: 用tag判斷
        if textField.tag == 1{
            shift = 60.0
        }else if textField.tag == 2{
            shift = 120.0
        }
        
        //讓view移動（x軸不動, y軸加回來）  註：y軸往上為正 往下為負  所以要把view移回來 就把shift加回來
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y + shift)
    }
    
    //實作觸控事件：因都是viewControl提供的 故實作時要override 注意：有四個(四種狀態) 且 全部都要實作(但未必裡面要寫程式碼)
    //註：Set<UITouch> 儲存使用者的觸控點  最多10跟手指 可處理複雜手勢
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態1：按下去接觸到螢幕的瞬間
        //收鍵盤
        myAccount.resignFirstResponder() //FirstResponder為目前畫面正接受觸控事件的UI 所以加上resign就會收起 常用於收鍵盤
        myPassword.resignFirstResponder()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態2：按到且滑動時
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態3：手指離開螢幕的瞬間
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態4：手指仍在螢幕但觸控事件被中斷 ex：有電話打來
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
