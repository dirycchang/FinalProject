//
//  Cell_Spot.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/22.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class Cell_Spot: UITableViewCell {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    let spot_NameLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let spot_AddressLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.caption1)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpViews() {
        backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)

        addSubview(spot_NameLabel)
        spot_NameLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        spot_NameLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        
        addSubview(spot_AddressLabel)
        spot_AddressLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        spot_AddressLabel.leftAnchor.constraint(equalTo: spot_NameLabel.leftAnchor).isActive = true
        spot_AddressLabel.rightAnchor.constraint(equalTo: spot_NameLabel.rightAnchor).isActive = true
        spot_AddressLabel.topAnchor.constraint(equalTo: spot_NameLabel.bottomAnchor).isActive = true
        
    }
    
    func displayMovieInCell(using viewModel: ViewModel_spot) {
        
        spot_NameLabel.text = viewModel.Name
        spot_AddressLabel.text = viewModel.Address

    }
}
