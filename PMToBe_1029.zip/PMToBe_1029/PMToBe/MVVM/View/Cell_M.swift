//
//  Cell_M.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class Cell_M: UITableViewCell {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    let M_Image: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.layer.cornerRadius = 40
        iv.backgroundColor = #colorLiteral(red: 1, green: 0.3864146769, blue: 0.4975627065, alpha: 1)
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.clipsToBounds = true
        return iv
    }()
    
    let M_NameLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let M_LocationLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.caption1)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let M_StyleLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .right
        l.textColor = .white
        return l
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpViews() {
        backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        addSubview(M_Image)
        M_Image.widthAnchor.constraint(equalToConstant: 80).isActive = true
        M_Image.heightAnchor.constraint(equalToConstant: 80).isActive = true
        M_Image.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        M_Image.leftAnchor.constraint(equalTo: leftAnchor, constant: 10).isActive = true
        
        addSubview(M_StyleLabel)
        M_StyleLabel.widthAnchor.constraint(equalToConstant: 100).isActive = true
        M_StyleLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        M_StyleLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: -10).isActive = true
        M_StyleLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        addSubview(M_NameLabel)
        M_NameLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        M_NameLabel.leftAnchor.constraint(equalTo: M_Image.rightAnchor, constant: 10).isActive = true
        M_NameLabel.rightAnchor.constraint(equalTo: M_StyleLabel.leftAnchor, constant: -10).isActive = true
        M_NameLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        
        addSubview(M_LocationLabel)
        M_LocationLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        M_LocationLabel.leftAnchor.constraint(equalTo: M_NameLabel.leftAnchor).isActive = true
        M_LocationLabel.rightAnchor.constraint(equalTo: M_NameLabel.rightAnchor).isActive = true
        M_LocationLabel.topAnchor.constraint(equalTo: M_NameLabel.bottomAnchor).isActive = true
        
    }
    
    func displayMovieInCell(using viewModel: ViewModel_M) {
        
        M_NameLabel.text = viewModel.ShowName
        M_LocationLabel.text = viewModel.Location
        M_StyleLabel.text = viewModel.ModelRole
        let myId = String(viewModel.UserId)
        appDelegate.strID_M.append(myId)
        
        appDelegate.strName_M.append(viewModel.ShowName)
        appDelegate.strStyle_M.append(viewModel.ModelRole)
        appDelegate.strLocation_M.append(viewModel.Location)
        appDelegate.strIntroduction_M.append(viewModel.Introduction)
        appDelegate.strPhone_M.append(viewModel.Phone)
        appDelegate.strProfile_M.append(viewModel.ProfileUrl)
        appDelegate.strGender_M.append(viewModel.Gender)
        
        M_Image.loadImageUsingCacheWithURLString(viewModel.ProfileUrl, placeHolder: nil) { (bool) in
            //perform actions if needed
        }
    }
}
