//
//  FindShowTableViewCell.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/8.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class FindShowTableViewCell: UITableViewCell {

    
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var lblName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
    }

}
