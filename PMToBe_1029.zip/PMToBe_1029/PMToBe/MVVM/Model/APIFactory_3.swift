//
//  APIFactory_3.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/19.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation

class APIFactory_3: NSObject{   //適用只有一個Dictionary
    
    //解析Name
    func parseExist(data: Data) -> Int{
        var resultName:Int = -1
        
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["result"] as! Int
            
            resultName = resDict2
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultName
    }
    
    
    
    
}




