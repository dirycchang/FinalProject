//
//  mStruct.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

struct mStruct {
    
    
    let UserId: Int
    let UserName: String
    let ShowName: String
    let ProfileUrl: String
    let ModelRole: String
    let Location: String
    let Introduction: String
    let AcceptStyle: String
    let Gender: String
    let Phone: String
    let Email:String
}

extension mStruct {
    
    struct Key  {
        
        
        static let datd = "data"
        static let UserId = "UserId"
        static let UserName = "UserName"
        static let ShowName = "ShowName"
        static let ProfileUrl = "ProfileUrl"
        static let ModelRole = "ModelRole"
        static let Location = "Location"
        static let Introduction = "Introduction"
        static let AcceptStyle = "AcceptStyle"
        static let Gender = "Gender"
        static let Phone = "Phone"
        static let Email = "Email"
        
        
    }
    
    //failable initializer
    init?(json: [String: AnyObject]) {
        
        
        guard
            let UserId = json[Key.UserId] as? Int,
            let UserName = json[Key.UserName] as? String,
            let ShowName = json[Key.ShowName] as? String,
            let ProfileUrl = json[Key.ProfileUrl] as? String,
            let ModelRole = json[Key.ModelRole] as? String,
            let Location = json[Key.Location] as? String,
            let Introduction = json[Key.Introduction] as? String,
            let AcceptStyle = json[Key.AcceptStyle] as? String,
            let Gender = json[Key.Gender] as? String,
            let Phone = json[Key.Phone] as? String,
            let Email = json[Key.Email] as? String
            
            else {
                return nil
        }
        
        //self.data = Data(Data: data)
        self.UserId = UserId
        self.UserName = UserName
        self.ShowName = ShowName
        self.ProfileUrl = ProfileUrl
        self.ModelRole = ModelRole
        self.Location = Location
        self.Introduction = Introduction
        self.AcceptStyle = AcceptStyle
        self.Gender = Gender
        self.Phone = Phone
        self.Email = Email
        
        
    }
    
}
