//
//  spotStruct.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/22.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

struct spotStruct {
    

    let Id : Int
    let Name: String
    let Address: String
    let Description: Any
    let PosX: Any
    let PosY: Any
    let GUID: String

}


extension spotStruct {
    
    struct Key  {
        
        static let Id = "Id"
        static let Name = "Name"
        static let Address =  "Address"
        static let Description =  "Description"
        static let PosX =  "PosX"
        static let PosY =  "PosY"
        static let GUID = "GUID"
        
    }
    
    //failable initializer
    init?(json: [String: AnyObject]) {
        
        guard
            let Id = json[Key.Id] as? Int,
            let Name = json[Key.Name] as? String,
            let Address = json[Key.Address] as? String,
            let Description = json[Key.Description] as? Any,
            let PosX = json[Key.PosX] as? Any,
            let PosY = json[Key.PosY] as? Any,
            let GUID = json[Key.GUID] as? String
        
            
            else {
                return nil
        }
        
        //self.data = Data(Data: data)
        self.Id = Id
        self.Name = Name
        self.Address = Address
        self.Description = Description
        self.PosX = PosX
        self.PosY = PosY
        self.GUID = GUID
        
    }
    
}
