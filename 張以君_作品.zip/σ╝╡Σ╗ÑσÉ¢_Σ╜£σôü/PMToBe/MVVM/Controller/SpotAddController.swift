//
//  ViewController.swift
//  MapCombine
//
//  Created by Yi Hwei Huang on 2018/10/2.
//  Copyright © 2018年 tw.iii.org. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation
import Firebase
import FirebaseStorage
import FirebaseAuth
import FirebaseDatabase

class SpotAddController: UIViewController , CLLocationManagerDelegate , UINavigationControllerDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate,UISearchBarDelegate,MKMapViewDelegate{
    
    
    
    @IBOutlet weak var SearchBarMap: UISearchBar!
    @IBOutlet weak var MapView: MKMapView!
    
    // VARIABLES
    let locationManager = CLLocationManager()
    //    var addressArray=[String]()
    var imgPicked=UIImage()
    var anno = MKPointAnnotation()
    let myImagePicker: UIImagePickerController = UIImagePickerController()
    let geocoder = CLGeocoder()
    var address:String=""
    var pickPhoto=UIButton()
    var addSpotBtn=UIButton(type: .custom)
    var spotDescri:String=""
    var lat:String=""
    var lon:String=""
    var InfoDict:String=""
    var addressArray:[String]=[]
    var mainAddress:String=""
    let apiFactory = APIFactory()
    var thelatestGUID:String=""
    var myarrayGUID:[String]=[]
    var strSpotData:Data?
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        locationManager = CLLocationManager()
        //        locationManager.delegate = self
        Auth.auth().signInAnonymously(completion: nil)
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
        locationManager.startMonitoringSignificantLocationChanges()
        SearchBarMap.delegate = self as? UISearchBarDelegate
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    
    // MARK: CLLocation Manager Delegate
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error while get location \(error)")
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        
    }
    
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        if pickPhoto.tag==101{
            pickPhoto.setImage(imgPicked, for: .normal)
        }
        
    }
    
    
    
    @objc func btnAdd_Click(_ sender:UIButton) {
        //@objc func buttonPress(_ sender:UIButton)
        
        if sender.tag==105{
            //            print("====tag 105 press once")
            let SpotAdd_AlertController=UIAlertController(title: "新增景點描述", message: "可自由輸入景點描述(限30字)\n或直接新增景點", preferredStyle: .alert)
            
            
            SpotAdd_AlertController.addTextField { (txtspotDecri)  in
                txtspotDecri.placeholder = "請輸入景點描述，限30字以下...."
                txtspotDecri.frame=CGRect(x: 10.0, y: 10.0, width: 70.0, height: 30.0)
                self.spotDescri=txtspotDecri.text!
            }
            
            let cancelAction=UIAlertAction(title: "取消", style: UIAlertActionStyle.cancel, handler: {
                (action) -> Void in
                //cancel
            })
            
            let okAction = UIAlertAction(title: "送出", style: UIAlertActionStyle.default, handler: {
                //closure閉包 -->handler is the keyword-->這是一段可以寫獨立的程式的地方，算是多重執行續的一部分
                (action) -> Void in
                let txtSpotDescri = SpotAdd_AlertController.textFields![0] as UITextField
                if txtSpotDescri.text == nil{
                    self.spotDescri=""
                }
                else{
                    self.spotDescri=txtSpotDescri.text!
                    print("okaction===>")
                }
                //------->執行送出資料到伺服器<-------------
                self.SaveTheSpot()
                //                var imgUpload=ImageUploadViewController.imagePickerController(SpotAddController.imgPicked)
                DispatchQueue.main.async {
                    let alertView = UIAlertController.init(title: "新增景點完成!", message: "", preferredStyle: .alert)
                    self.present(alertView, animated: true, completion: nil)
                    self.presentedViewController?.dismiss(animated: false, completion: nil)
                    
//                    //顯示祕境視圖
//                    let LocationVC: SpotListController = self.storyboard?.instantiateViewController(withIdentifier: "SecondMap") as! SpotListController
//                    self.present(LocationVC, animated: true, completion: nil)
                }
            })
            
            
            
            //add button on alertview to controller
            
            SpotAdd_AlertController.addAction(okAction)
            SpotAdd_AlertController.addAction(cancelAction)
            
            
            self.present(SpotAdd_AlertController,animated: true,completion: nil)
            //
            //
        }
        
    }
    
    
    
    
    func SaveTheSpot(){
        ///原本要做資料傳送的段落
        
        
        if SearchBarMap.text != nil{
            //*******************記得修改代值問題
            
            
            let PostData:[String:Any]=["PosX":"\(lon)","PosY":"\(lat)","Address":"\(mainAddress)","Name":"\(SearchBarMap.text!)","Description":"\(spotDescri)"]
            
            //            print(PostData,"========Post data=======")
            
            
                //                print(token,"=======>token in spot upload")
                
                let strurl:String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot?accessuid=2"
                
                //                    print("=======data is go to server=======")
                //"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot"
                let strPerEsc: String = strurl.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
                let myURL = URL(string: strPerEsc)!
                let SessionConfig = URLSessionConfiguration.default
                let session = URLSession(configuration: SessionConfig, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: myURL)
                
                request.httpMethod = "POST"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: PostData, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                    }
                    
                    if let data = data{ //body裡面的東西
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
            }///原本段落結束
        
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        //確認選取
        let tookImage: UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage
        
                let storageRef = Storage.storage().reference().child("pic")
        
                var image:UIImage?
                if let myImage = info[UIImagePickerControllerOriginalImage] as? UIImage{
                    image = myImage
                }
        

                var filename = "image.JPG"
                if let url = info[UIImagePickerControllerImageURL] as? URL{
                    print(url,"======>url")
                    filename = url.lastPathComponent
                    print(filename,"=====>lastpath")
                }
        
                if let theUid = UserDefaults.standard.value(forKey: "thisId") as? String{
                    if let data = UIImageJPEGRepresentation(image!, 0.1){ //UIImageJPEGRepresentation(設壓縮比)
        
                        //建立中介資料
                        let myMetadata = StorageMetadata()
        
                        myMetadata.contentType = "image/jpeg" //***轉為圖擋
        
                        myMetadata.customMetadata = ["myKey":"myValue"] //可自訂metadata 將要的資訊設在Storage中
        
        
                        //＊＊＊上傳 子目錄：第一層為使用者Id  第二層為檔案名稱  putData上傳檔案
                        let task = storageRef.child(theUid).child(filename).putData(data, metadata: myMetadata) { (metadata, error) in //完成時會回傳: 真正完成的metadata跟Error
        
        //                    self.uploadStatus.isHidden = true //上傳成功與否 都將進度條隱藏
        
                            if  error == nil{
        
                                //若上傳成功
                                let dataRef = Database.database().reference().child("pic")
        
                                storageRef.child(theUid).child(filename).downloadURL(completion: {
        
                                    (url, error) in
        
                                    //print("\(url)--------")
                                    if error != nil {
        
                                        return
                                    } else {
        
                                        let url = url?.absoluteString //＊＊＊取得URL的字串
                                        print("======urlabsolute string ====",url!)
                                        let value = ["uid":theUid,"link":url!]
        
                                        dataRef.childByAutoId().setValue(value)
                                        
                                        self.strSpotData=self.apiFactory.getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot")
                                        
                                        print("get all spot json")
                  
                                        self.myarrayGUID=APIFactory().parseThelatestSpotGUID(data:self.strSpotData!) as! [String]
                                        
                                        print("parse guid finish")
                                        
                                        self.thelatestGUID = self.myarrayGUID.last!
                                        
                                        print(self.thelatestGUID,"thelatestGUID")
                                        
                                        let newURL = self.apiFactory.postSpotPhotoToDatabase(GUId: self.thelatestGUID, firebaseURL: url!)
                                        print(newURL,"new url")
                                        
                                        
//                                        print("==最新url==",newURL)
        

                                    }
                                })
                            }
                            
                            else
                            {
                                //若上傳失敗 印出錯誤
                                print(error?.localizedDescription)
                            }
                        }
        
                    }
                }
        
        pickPhoto.tag=101
        imgPicked = tookImage
        picker.dismiss(animated: true, completion: nil)
        
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        //取消
        picker.dismiss(animated: true, completion: nil)
    }
    
    
    
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        
        SearchBarMap.resignFirstResponder()
        
        //address --> lat,lon
        geocoder.geocodeAddressString(SearchBarMap.text!) { (placemarks:[CLPlacemark]?, error:Error?) in
            if error == nil {
                
                //                print(self.geocoder)
                let placemark = placemarks?.first
                
                self.anno.coordinate = (placemark?.location?.coordinate)!
                
                self.lat=String(format: "%f", self.anno.coordinate.latitude)
                self.lon=String(format: "%f", self.anno.coordinate.longitude)
                print(self.lat,self.lon,"====>")
                
                self.anno.title = self.SearchBarMap.text!
                
                let span = MKCoordinateSpanMake(0.075, 0.075)
                let region = MKCoordinateRegion(center: self.anno.coordinate, span: span)
                
                
                let location=CLLocation(latitude: self.anno.coordinate.latitude, longitude: self.anno.coordinate.longitude)
                
                
                //lat,lon-->address
                
                self.MapView.setRegion(region, animated: true)
                self.MapView.addAnnotation(self.anno)
                self.MapView.selectAnnotation(self.anno, animated: true)
                
                //轉譯地址
                self.reversGeocoding(lat:self.lat,lon:self.lon)
               
            }
            else{
                print(error?.localizedDescription ?? "error")
            }
            
        }
        
    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation{
            print("annotation is MKUserLocation")
            return nil
        }
        
        var annView=mapView.dequeueReusableAnnotationView(withIdentifier: "Pin")
        if (annView==nil){
            annView=MKPinAnnotationView(annotation: annotation, reuseIdentifier: "Pin")
            //            print("mapView.dequeueReusableAnnotationView")
        }
        
        
        //callout panel
        if (annotation.title)!==SearchBarMap.text!{
            
            
            pickPhoto.frame=CGRect(x: 10.0, y: 10.0, width:40.0 , height: 40.0)
            pickPhoto.setImage(#imageLiteral(resourceName: "gallery2"), for: .normal)
            pickPhoto.tag=100
            pickPhoto.addTarget(self, action: #selector(SpotAddController.pickPhoto_buttonPress), for: UIControlEvents.touchUpInside)
            annView?.leftCalloutAccessoryView=pickPhoto
            
            let addresslbl=UILabel()
            addresslbl.numberOfLines=3
            addresslbl.frame=CGRect(x: 5.0, y: 5.0, width: 40.0, height: 40.0)
            addresslbl.text=self.address
            addresslbl.font=addresslbl.font.withSize(10)
            annView?.detailCalloutAccessoryView=addresslbl
            
            //right add btn
            
            addSpotBtn.setImage(#imageLiteral(resourceName: "plus-symbol"), for: .normal)
            addSpotBtn.frame=CGRect(x: 40.0, y: 75.0, width: 15.0, height: 15.0)
            addSpotBtn.tag=105
            addSpotBtn.addTarget(self, action: #selector(SpotAddController.btnAdd_Click(_:)), for: UIControlEvents.touchUpInside)
            annView?.rightCalloutAccessoryView=addSpotBtn
            
            
        }
        annView?.canShowCallout=true
        return annView
    }
    
    @objc func pickPhoto_buttonPress(_ sender:UIButton){
        if sender.tag==100{
            myImagePicker.delegate = self as! UIImagePickerControllerDelegate & UINavigationControllerDelegate
            myImagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
            
            self.present(myImagePicker, animated: true, completion: nil)
        }
    }
    
    func reversGeocoding(lat:String,lon:String){
        print("======myfunc reversegeocoding =========")
        let strURL: String = "https://maps.googleapis.com/maps/api/geocode/json?latlng=\(lat),\(lon)&language=zh_TW"
        
        print(strURL)
        

        let strPerEsc:String=strURL.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        let myURL: URL = URL(string: strPerEsc)!
        let mySessionConfig = URLSessionConfiguration.default
        let mySession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
        

        var myRequest = URLRequest(url: myURL)
        myRequest.httpMethod = "GET"
        
        let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
            (data: Data?, response: URLResponse?, error: Error?) -> Void in
            
            if error == nil {
                let statusCode = (response as! HTTPURLResponse).statusCode
                print("http狀態碼:\(statusCode)")
                print("共下載:\(data!.count)bytes")
                print("===>data")
                print(data as Any)
                
                ////解析JSON＊＊註：因為value有很多種可能  所以建議都用[String: Any]的形式表示Dictionary
                do {
                    let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data!, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
                    
                    
                    print("查詢狀態:\(resDict["status"]!)")
                    
                    
                    let arrayResult: [[String: Any]] = resDict["results"] as! [[String:Any]]
                    
                    
                    //                   var dict=[String:String]()
                    for myDict: [String: Any] in arrayResult {
                        let address=myDict["formatted_address"] as! String
                        self.addressArray.append(address)
                        
                        //    self.str = myDict["formatted_address"] as! String
                        //    self.str = "\n"
                        print("查到的地址是:\(myDict["formatted_address"]!)")
                        //                        print("place_id:\(myDict["place_id"]!)")
                        //                        print(self.addressArray,"=====addressArray")
                    }
                    
                    //存第一筆地址起來
                    if self.addressArray.first == nil{
                        self.mainAddress="can't get address"
                    }
                    else{
                        self.mainAddress=self.addressArray.first!
                    }
                    
                    print(self.mainAddress,"======main address")
                }
                catch {
                    print("解析錯誤:\(error)")
                }
                ////////////
            } else {
                print("錯誤:\(String(describing: error?.localizedDescription))")
            }
        })
        myDataTask.resume()
        
    }
    
    
    
    
    
   
    
    
    
}





