//
//  DetailViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/25.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import MessageUI

class DetailViewController: UIViewController,MFMailComposeViewControllerDelegate{
   //,UICollectionViewDelegate,UICollectionViewDataSource
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    @IBOutlet weak var sharedImagesCollection: UICollectionView!
    let apiFactory = APIFactory()
    var strDataPpic:Data? //攝影師作品Data
    var strDataMpic:Data? //模特兒作品Data
    var pPicArray:[String] = [] //攝影師作品
    var mPicArray:[String] = [] //模特兒作品
    
    var strData_PName:Data? //攝影師屬性Data
    var strData_MName:Data? //模特兒屬性Data
    
    @IBOutlet weak var myName: UILabel!
    @IBOutlet weak var lbl風格: UILabel!
    @IBOutlet weak var lbl電話: UILabel!
    @IBOutlet weak var lbl地點: UILabel!
    var p_id:Int = 0 //所選攝影師Id值
    var m_id:Int = 0 //所選模特兒的Id值
    var p_name:String = ""
    var m_name:String = ""
    var p_style:String = "" //所選攝影師風格值
    var m_style:String = "" //所選模特兒風格值
    var p_location:String = "" //所選攝影師地點值
    var m_location:String = "" //所選模特兒地點值
    var p_phone:String = "" //所選攝影師電話值
    var m_phone:String = "" //所選模特兒電話值
    var p_pic:String = ""
    var m_pic:String = ""
    var p_Email:String = ""
    var m_Email:String = ""
    
    @IBAction func btn寄信給我_Click(_ sender: Any) {
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
            DispatchQueue.main.async {
                let alertView = UIAlertController.init(title: "成功寄出！", message: "", preferredStyle: .alert)
                self.present(alertView, animated: true, completion: nil)
                self.presentedViewController?.dismiss(animated: false, completion: nil)
            }
            
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
        if appDelegate.strChooseCharacter == "攝影師"{
            
            mailComposerVC.setToRecipients(["\(p_Email)"])
            mailComposerVC.setSubject("有一則合作邀請")
            mailComposerVC.setMessageBody(" 我想找你合作 ", isHTML: false)
        }else if appDelegate.strChooseCharacter == "模特兒"{
            
            mailComposerVC.setToRecipients(["\(m_Email)"])
            mailComposerVC.setSubject("有一則合作邀請")
            mailComposerVC.setMessageBody(" 我想找你合作 ", isHTML: false)
        }
        
        
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertController(title: "無法發送電子郵件", message: "您的設備無法發送電子郵件。請檢查電子郵件配置，然後重試。", preferredStyle: UIAlertControllerStyle.alert)
        sendMailErrorAlert.show(sendMailErrorAlert, sender: nil)
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
   

    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        sharedImagesCollection.frame = CGRect(x: 0, y: 260, width: 375, height: 407)
//        sharedImagesCollection.delegate = self
//        sharedImagesCollection.dataSource = self

        if appDelegate.strChooseCharacter == "攝影師"{
            let loadId = p_id
            print("===這pid===",loadId)
            self.myName.text = p_name
            self.lbl風格.text = p_style
            self.lbl電話.text = p_phone
            self.lbl地點.text = p_location
            
            strDataPpic = APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/image?uid=\(loadId)")
            pPicArray = apiFactory.parse_Product(data: strDataPpic!) as! [String]
            
            print("==pic==!!",pPicArray)
            
            
            for i in 0..<pPicArray.count{
                
                let imageView = UIImageView()
                imageView.frame = CGRect(x:20+i*70, y:300, width:65, height:65)
                imageView.tag = i
                imageView.contentMode = .scaleAspectFill
                imageView.clipsToBounds = true
                if let url = URL(string:pPicArray[i]){
                    let downloadTask = URLSession.shared.dataTask(with: url){
                        (data,response,error) in
                        guard let imageData = data else {return}
                        OperationQueue.main.addOperation{
                            guard let image = UIImage(data: imageData) else {return} //將imageData轉為UIImage 就繼續往下執行 否則return
                            //加圖片至快取
                            imageView.image = image
                            imageView.layer.masksToBounds = true
                            imageView.layer.cornerRadius = 5

                            CacheManager.shared.cache(object: image, key: self.pPicArray[i])

                        }
                    }
                    downloadTask.resume()
                }

                imageView.isUserInteractionEnabled = true
                self.view.addSubview(imageView)
                
                let tapSingle=UITapGestureRecognizer(target:self,
                                                     action:#selector(imageViewTap(_:)))
                tapSingle.numberOfTapsRequired = 1
                tapSingle.numberOfTouchesRequired = 1
                imageView.addGestureRecognizer(tapSingle)
            }
            
            
        }else if appDelegate.strChooseCharacter == "模特兒"{
            
            let loadId = m_id
            print("===這mid===",loadId)
            
            self.myName.text = m_name
            self.lbl風格.text = m_style
            self.lbl電話.text = m_phone
            self.lbl地點.text = m_location
            
            strDataMpic = APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/image?uid=\(loadId)")
            mPicArray = apiFactory.parse_Product(data: strDataMpic!) as! [String]
            
            //生成缩略图
            for i in 0..<mPicArray.count{
                
                let imageView = UIImageView()
                imageView.frame = CGRect(x:20+i*70, y:300, width:60, height:60)
                imageView.tag = i
                imageView.contentMode = .scaleAspectFill
                imageView.clipsToBounds = true
                
                if let url = URL(string:mPicArray[i]){
                    let downloadTask = URLSession.shared.dataTask(with: url){
                        (data,response,error) in
                        guard let imageData = data else {return}
                        OperationQueue.main.addOperation{
                            guard let image = UIImage(data: imageData) else {return} //將imageData轉為UIImage 就繼續往下執行 否則return
                            //加圖片至快取
                            imageView.image = image
                            imageView.layer.masksToBounds = true
                            imageView.layer.cornerRadius = 5
                            
                            CacheManager.shared.cache(object: image, key: self.mPicArray[i])
                            
                        }
                    }
                    downloadTask.resume()
                }

                imageView.isUserInteractionEnabled = true
                self.view.addSubview(imageView)
                let tapSingle=UITapGestureRecognizer(target:self,
                                                     action:#selector(imageViewTap(_:)))
                tapSingle.numberOfTapsRequired = 1
                tapSingle.numberOfTouchesRequired = 1
                imageView.addGestureRecognizer(tapSingle)
  
            }
            
        }
 
    }

    @objc func imageViewTap(_ recognizer:UITapGestureRecognizer){
        
        let index = recognizer.view!.tag
        if appDelegate.strChooseCharacter == "攝影師"{
            let previewVC = ImagePreviewVC(images: pPicArray, index: index)
            self.navigationController?.pushViewController(previewVC, animated: true)
        }else if appDelegate.strChooseCharacter == "模特兒"{
            let previewVC = ImagePreviewVC(images: mPicArray, index: index)
            self.navigationController?.pushViewController(previewVC, animated: true)
        }
        
        
    }
    
//    //實作以下兩個CollectionView的方法
//    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
//
//        let nameCount:Int = 0
//
//        if appDelegate.strChooseCharacter == "攝影師"{
//            return pPicArray.count
//        }else if appDelegate.strChooseCharacter == "模特兒"{
//            return mPicArray.count
//        }
//
//        return nameCount
//    }
    
//    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
//
//        let cell = sharedImagesCollection.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! MyCollectionViewCell
//
//        if appDelegate.strChooseCharacter == "攝影師"{
//
//            if let url = URL(string:pPicArray[indexPath.row]){
//                let downloadTask = URLSession.shared.dataTask(with: url){
//                    (data,response,error) in
//                    guard let imageData = data else {return} //將data指定給imageData 就繼續往下執行 否則return
//                    OperationQueue.main.addOperation{
//                        guard let image = UIImage(data: imageData) else {return} //將imageData轉為UIImage 就繼續往下執行 否則return
//                        //加圖片至快取
//                        cell.image.image = image
//                        //圖片改圓角
//                        cell.layer.masksToBounds = true
//                        cell.layer.cornerRadius = 10
//                        CacheManager.shared.cache(object: image, key: self.pPicArray[indexPath.row])
//                    }
//                }
//                downloadTask.resume()
//            }
//
//        }else if appDelegate.strChooseCharacter == "模特兒"{
//            if let url = URL(string:mPicArray[indexPath.row]){
//                let downloadTask = URLSession.shared.dataTask(with: url){
//                    (data,response,error) in
//                    guard let imageData = data else {return}
//                    OperationQueue.main.addOperation{
//                        guard let image = UIImage(data: imageData) else {return}
//                        //加圖片至快取
//                        cell.image.image = image
//                        //圖片改圓角
//                        cell.layer.masksToBounds = true
//                        cell.layer.cornerRadius = 10
//                        CacheManager.shared.cache(object: image, key: self.mPicArray[indexPath.row])
//                    }
//                }
//                downloadTask.resume()
//            }
//        }
//        return cell
//
//    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
