//
//  BlogViewController.swift
//  PMToBe
//
//  Created by Yi Hwei Huang on 2018/10/21.
//  Copyright © 2018 YiChun. All rights reserved.
//

import UIKit

class BlogViewController: UIViewController,UIWebViewDelegate{

    @IBOutlet weak var webView: UIWebView!
    @IBOutlet weak var activityView: UIActivityIndicatorView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.webView.delegate=self as! UIWebViewDelegate
        self.activityView.isHidden=true
        self.activityView.hidesWhenStopped=true
        
        let strUrl:String="http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com"
        let myUrl:URL=URL(string: strUrl)!
        let myURLRequest:URLRequest=URLRequest(url: myUrl)
        self.webView.loadRequest(myURLRequest)
       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
    
    func webViewDidStartLoad(_ webView: UIWebView) {
        self.activityView.isHidden=false
        self.activityView.stopAnimating()
    }
    
    func webViewDidFinishLoad(_ webView: UIWebView) {
        self.activityView.isHidden=true
        self.activityView.stopAnimating()
    }
    

    

}
