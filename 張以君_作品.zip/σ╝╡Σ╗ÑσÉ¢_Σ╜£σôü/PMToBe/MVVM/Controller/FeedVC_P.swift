//
//  FeedVC_P.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit
import Speech


class FeedVC_P: UIViewController,UITableViewDataSource, UITableViewDelegate,UISearchResultsUpdating,SFSpeechRecognizerDelegate, SFSpeechRecognitionTaskDelegate{
    
    // 語音識別對象,這裏直接給出識別語言(繁體中文)
    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "zh_TW"))!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioSession = AVAudioSession.sharedInstance()
    private let audioEngine = AVAudioEngine()
    private var micButtonEnabled = false
    private var recordResult:String = ""
    private var timer:Timer!
    
    var myWords = [pStruct]()
    
    var searchController: UISearchController!
//    var hidesSearchBarWhenScrolling: Bool!
    
    var searchAdv = [pStruct]()
    var searchResults = [String]()
    
    var strDataPName:Data?
    var strDataMName:Data?
    var strDataP_pic:Data?
    var strDataM_pic:Data?
    
    
    var getFilterResult:[String] = [String]()
    var pName:[String] = [] //攝影師姓名
    var mName:[String] = [] //模特兒姓名
    var profile_P:[String] = [] //攝影師大頭照
    var profile_M:[String] = [] //模特兒大頭照
    var pId:[String] = [] //攝影師Id
    var mId:[String] = [] //模特兒Id
    
    
    var myCharacter:String = ""
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    func updateSearchResults(for searchController: UISearchController) {
        
        let searchString = searchController.searchBar.text!
        searchAdv = moviesArray.filter { (myStruct) -> Bool in
            return myStruct.Location.contains(searchString) || myStruct.ShowName.contains(searchString) || myStruct.PhotoType.contains(searchString)
        }
        tableView.reloadData()
    }
    
    @IBAction func btn語音_Click(_ sender: UIBarButtonItem) {
        startRecording()
    }
    
    @IBOutlet weak var tableView: UITableView!
    
    private let cellID = "cellID"
    private var moviesArray = [pStruct]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    let service = Service_P()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        myCharacter = "攝影師"
        appDelegate.strChooseCharacter = myCharacter
 
        tableView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tableView.register(Cell_P.self, forCellReuseIdentifier: cellID)
        tableView.contentInset = UIEdgeInsets(top: 22, left: 0, bottom: 0, right: 0)
        getMovies(fromService: service)
        
        navigationController?.navigationBar.prefersLargeTitles = true
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        navigationItem.searchController = searchController
        searchController.searchBar.placeholder = "以姓名、風格、地區來篩選"
        searchController.searchBar.searchBarStyle = .minimal
        searchController.searchBar.barTintColor = .white
//        tableView.tableHeaderView = searchController.searchBar
        definesPresentationContext = true
        navigationItem.hidesSearchBarWhenScrolling = false//讓searchbar固定顯示在畫面上
        navigationController?.navigationBar.prefersLargeTitles = false
        
        speechRecognizer.delegate = self
        // 語音識別權限請求
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            switch authStatus {
            case .authorized:
                // 通過授權
                self.micButtonEnabled = true
                break
            case .denied:
                // 拒絕授權
                self.micButtonEnabled = false
                break
            case .restricted:
                // 權限受限制
                self.micButtonEnabled = false
                break
            case .notDetermined:
                // 權限不明確
                self.micButtonEnabled = false
                break
            }
        }

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        // 獲取當前語音識別權限
        AVAudioSession.sharedInstance().requestRecordPermission { (permiss:Bool) in
            self.micButtonEnabled = permiss
        }
    }
    

    func startRecording(){
        if !audioEngine.isRunning {
            recordResult = ""
            recording()
        }
    }
    
    func stopRecording(){
        if (recognitionRequest != nil) {
            recognitionRequest?.endAudio()
        }
    }
    

    func recording() {

        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        do {
            
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        // 初始化識別請求
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true
       
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest, delegate: self)
        
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        audioEngine.prepare()
        do {
            
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }
    }
    
    /******* 以下都是代理方法 *******/
    
    // 判斷當前是否連接網絡
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {
        
    }
    
    
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didHypothesizeTranscription transcription: SFTranscription) {
        
        if(timer != nil && timer.isValid){
            timer.invalidate()
            timer = nil
        }
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true, block: { (Timer) in
            self.stopRecording()
        })
        
    }
    
    // 開始識別語音
    func speechRecognitionTaskFinishedReadingAudio(_ task: SFSpeechRecognitionTask) {
        
    }
    
    // 錄音結束之後的識別處理
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishRecognition recognitionResult: SFSpeechRecognitionResult) {
        print(recognitionResult)
        recordResult = recognitionResult.bestTranscription.formattedString
    }
    
    // 語音轉文本結束
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishSuccessfully successfully: Bool) {
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        self.recognitionRequest = nil
        self.recognitionTask = nil
        do {
            
            try audioSession.setCategory(AVAudioSessionCategoryAmbient)
        }catch let error as NSError{
            print(error.code)
        }
        if(timer != nil){
            timer.invalidate()
            timer = nil
        }
        
        
        
    }
    
    
    private func getMovies<S: Gettable_P>(fromService service: S) where S.T == Array<pStruct?> {
        
        service.get { [weak self] (result) in
            switch result {
            case .Success(let movies):
                var tempMovies = [pStruct]()
                for movie in movies {
                    if let movie = movie {
                        tempMovies.append(movie)
                    }
                }
                self?.moviesArray = tempMovies
            //dump(self.movies)
            case .Error(let error):
                print(error)
            }
        }
    }
    
//    func dummyMovie() {
//        let dummyMovie = pStruct(UserId: 1, UserName: "test", ShowName: "test1", ProfileUrl: "111", PhotoType: "1", Location: "1", Introduction: "2", AcceptStyle: "1", Gender: "1", Phone: "1")
//        moviesArray.append(dummyMovie)
//    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID) as! Cell_P
//        let movie = moviesArray[indexPath.row]
//        let movieViewModel = ViewModel_P(model: movie)
        
        if navigationItem.searchController?.isActive == true {
            let movie = searchAdv[indexPath.row]
            let movieViewModel = ViewModel_P(model: movie)
            cell.displayMovieInCell(using: movieViewModel)
        } else {
            let movie = moviesArray[indexPath.row]
            let movieViewModel = ViewModel_P(model: movie)
            cell.displayMovieInCell(using: movieViewModel)
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if navigationItem.searchController?.isActive == true {
            return searchAdv.count
        } else {
            return moviesArray.count
        }

    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    //點擊儲存格
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        var loadID:String = ""
        //點擊儲存格
        if myCharacter == "攝影師"{
            
            print(indexPath.row) //TableView第幾列
            print("==pId==",pId)

            let myVCDetail: DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc詳細資訊") as! DetailViewController
            if navigationItem.searchController?.isActive == true {
                //若有用Search Bar來搜尋 就用searchAdv
                myVCDetail.p_id = searchAdv[indexPath.row].UserId
                myVCDetail.p_name = searchAdv[indexPath.row].ShowName
                myVCDetail.p_style = searchAdv[indexPath.row].PhotoType
                myVCDetail.p_location = searchAdv[indexPath.row].Location
                myVCDetail.p_phone = searchAdv[indexPath.row].Phone
                myVCDetail.p_Email = searchAdv[indexPath.row].Email
            } else {
                //若沒用Search Bar來搜尋 就用原來的moviesArray
                myVCDetail.p_id = moviesArray[indexPath.row].UserId
                myVCDetail.p_name = moviesArray[indexPath.row].ShowName
                myVCDetail.p_style = moviesArray[indexPath.row].PhotoType 
                myVCDetail.p_location = moviesArray[indexPath.row].Location
                myVCDetail.p_phone = moviesArray[indexPath.row].Phone
                myVCDetail.p_Email = moviesArray[indexPath.row].Email
                
            }
            
            
            self.navigationController?.show(myVCDetail, sender: nil)
            
        }
    }

}
