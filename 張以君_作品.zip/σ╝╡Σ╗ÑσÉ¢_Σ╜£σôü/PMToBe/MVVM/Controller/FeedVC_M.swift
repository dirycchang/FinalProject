//
//  FeedVC_M.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class FeedVC_M: UIViewController,UITableViewDataSource, UITableViewDelegate, UISearchResultsUpdating{
    

    var searchAdv = [mStruct]() 
    
    var pName:[String] = [] //攝影師姓名
    var mName:[String] = [] //模特兒姓名
    var profile_P:[String] = [] //攝影師大頭照
    var profile_M:[String] = [] //模特兒大頭照
    var pId:[String] = [] //攝影師Id
    var mId:[String] = [] //模特兒Id
    
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchString = searchController.searchBar.text!
        searchAdv = moviesArray.filter { (myStruct) -> Bool in
            return myStruct.Location.contains(searchString) || myStruct.ShowName.contains(searchString) || myStruct.ModelRole.contains(searchString)
        }
        tableView.reloadData()
    }
    
    @IBAction func btn語音_Click(_ sender: UIBarButtonItem) {
        
    }
    
    
    @IBOutlet weak var tableView: UITableView!
    var myCharacter:String = ""
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    private let cellID = "cellID"
    private var moviesArray = [mStruct]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    let service = Service_M()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        myCharacter = "模特兒"
        appDelegate.strChooseCharacter = myCharacter
        
        tableView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tableView.register(Cell_M.self, forCellReuseIdentifier: cellID)
        tableView.contentInset = UIEdgeInsets(top: 22, left: 0, bottom: 0, right: 0)
        getMovies(fromService: service)
        
        navigationController?.navigationBar.prefersLargeTitles = true
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        navigationItem.searchController = searchController
        searchController.searchBar.placeholder = "以姓名、風格、地區來篩選"
        searchController.searchBar.searchBarStyle = .minimal
        searchController.searchBar.barTintColor = .white
        definesPresentationContext = true
//        navigationItem.hidesSearchBarWhenScrolling = false//讓searchbar固定顯示在畫面上
        navigationController?.navigationBar.prefersLargeTitles = false
    }
    
    private func getMovies<S: Gettable_M>(fromService service: S) where S.T == Array<mStruct?> {
        
        service.get { [weak self] (result) in
            switch result {
            case .Success(let movies):
                var tempMovies = [mStruct]()
                for movie in movies {
                    if let movie = movie {
                        tempMovies.append(movie)
                    }
                }
                self?.moviesArray = tempMovies
            //dump(self.movies)
            case .Error(let error):
                print(error)
            }
        }
    }
    
//    func dummyMovie() {
//
//        let dummyMovie = mStruct(UserId: 1, UserName: "test", ShowName: "test1", ProfileUrl: "111", ModelRole: "1", Location: "1", Introduction: "2", AcceptStyle: "1", Gender: "1", Phone: "1")
//        moviesArray.append(dummyMovie)
//    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID) as! Cell_M
        if navigationItem.searchController?.isActive == true {
            let movie = searchAdv[indexPath.row]
            let movieViewModel = ViewModel_M(model: movie)
            cell.displayMovieInCell(using: movieViewModel)
        } else {
            let movie = moviesArray[indexPath.row]
            let movieViewModel = ViewModel_M(model: movie)
            cell.displayMovieInCell(using: movieViewModel)
        }
        return cell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if navigationItem.searchController?.isActive == true {
            return searchAdv.count
        } else {
            return moviesArray.count
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath){
        
        var loadID:String = ""
        //點擊儲存格
        
        if myCharacter == "模特兒"{
            let myVCDetail: DetailViewController = self.storyboard?.instantiateViewController(withIdentifier: "vc詳細資訊") as! DetailViewController
            
            if navigationItem.searchController?.isActive == true {
                myVCDetail.m_id = searchAdv[indexPath.row].UserId
                myVCDetail.m_name = searchAdv[indexPath.row].ShowName
                myVCDetail.m_style = searchAdv[indexPath.row].ModelRole
                myVCDetail.m_location = searchAdv[indexPath.row].Location
                myVCDetail.m_phone = searchAdv[indexPath.row].Phone
                myVCDetail.m_Email = searchAdv[indexPath.row].Email
                
            } else {
                myVCDetail.m_id = moviesArray[indexPath.row].UserId
                myVCDetail.m_name = moviesArray[indexPath.row].ShowName
                myVCDetail.m_style = moviesArray[indexPath.row].ModelRole
                myVCDetail.m_location = moviesArray[indexPath.row].Location
                myVCDetail.m_phone = moviesArray[indexPath.row].Phone
                myVCDetail.m_Email = moviesArray[indexPath.row].Email
            }
            
            self.navigationController?.show(myVCDetail, sender: nil)
        }
        
    }
    
}
