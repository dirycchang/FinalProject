//
//  EditMemberViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/11.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth
import Speech
import FirebaseDatabase

class EditMemberViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate,SFSpeechRecognizerDelegate, SFSpeechRecognitionTaskDelegate,UITextFieldDelegate{


    
    
    //語音輸入地址
    @IBAction func btn語音_Click(_ sender: UIButton) {
        startRecording()
        
    }


    private let speechRecognizer = SFSpeechRecognizer(locale: Locale.init(identifier: "zh_TW"))!
    private var recognitionRequest: SFSpeechAudioBufferRecognitionRequest?
    private var recognitionTask: SFSpeechRecognitionTask?
    private let audioSession = AVAudioSession.sharedInstance()
    private let audioEngine = AVAudioEngine()
    private var micButtonEnabled = false
    private var recordResult:String = ""
    private var timer:Timer!
    
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var txt姓名: UITextField!
    @IBOutlet weak var txt電話: UITextField!
    @IBOutlet weak var txt地區: UITextField!
    @IBAction func txt姓名_EndEdit(_ sender: UITextField) {
    }
    @IBAction func txt電話_EndEdit(_ sender: UITextField) {
    }
    
    @IBAction func txt地區_EndEdit(_ sender: UITextField) {
    }
    
    @IBOutlet weak var seg角色: UISegmentedControl!
    @IBOutlet weak var seg性別: UISegmentedControl!
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var strData_Info:Data?
    var strData_Info2:Data?
    var strData_Info3:Data?
    var myName:String = "" //姓名
    var myGender:String = ""//性別
    var myEmail:String = "" //信箱
    var myCharacter:String = "攝影師" //預設攝影師
    var id:String = ""
    var profile:String = "aa" //大頭照
    var Exist_P:Int = -1 //是否已選擇為P
    var Exist_M:Int = -1 //是否已選擇為M
    var myPhone:String = ""
    var myLocation:String = ""
    
//    let activityIndicator = UIActivityIndicatorView(activityIndicatorStyle: .white)
    
    
    @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
    
    let messageFrame = UIView()
    let strLabel = UILabel(frame: CGRect(x: 50, y: 0, width: 160, height: 50))
    
    func displayActivityIndicator() {
        strLabel.text = "Loading..."
        strLabel.textColor = .white
        messageFrame.layer.cornerRadius = 15
        messageFrame.backgroundColor = UIColor(white: 0, alpha: 0.7)
        activityIndicator.frame = CGRect(x: 0, y: 0, width: 50, height: 50)
        activityIndicator.startAnimating()
        messageFrame.addSubview(activityIndicator)
        messageFrame.addSubview(strLabel)
        view.addSubview(messageFrame)
    }
    
    @IBAction func seg角色_ValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0{
            if let character = sender.titleForSegment(at: 0){
                myCharacter = character //無
                print("==角色0==",myCharacter)

            }
        }else if sender.selectedSegmentIndex == 1{
            if let character = sender.titleForSegment(at: 1){
                myCharacter = character //攝影師
                print("==角色1==",myCharacter)
            }
        }else if sender.selectedSegmentIndex == 2{
            if let character = sender.titleForSegment(at: 2){
                myCharacter = character //模特兒
                print("==角色2==",myCharacter)
            }
        }
    }
    
    
    @IBAction func seg性別_ValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0{
            if let gender = sender.titleForSegment(at: 0){
                myGender = gender
                print("==性別==0",myGender)
                
            }
        }else if sender.selectedSegmentIndex == 1{
            if let gender = sender.titleForSegment(at: 1){
                myGender = gender
                print("==性別==1",myGender)
            }
        }
    }
    
    
    @IBAction func btn儲存_Click(_ sender: UIBarButtonItem) {
        
        myPhone = txt電話.text ?? ""
        myLocation = txt地區.text ?? ""

        if Exist_P == -1 && Exist_M == -1{
            //還沒選角色 新增POST
            if myCharacter == "攝影師"{
                let postdata:[String: Any] = ["Uid":"\(id)","ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                print("==post測試1==：",postdata)
                print("==角色1==",myCharacter)
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p")
                print("==url==",url!)
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "POST"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            
                            print(self.myName as! String)
                            print(self.myPhone as! String)
                            print(self.myLocation as! String)
                            print(json)
                            print("完成 P POST 1")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //改大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("改大頭照 P PUT 1-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()
                
            }else if myCharacter == "模特兒"{
                //POST
                let postdata:[String: Any] = ["Uid":"\(id)","ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)",]
                print("==post測試2==：",postdata)
                print("==角色2==",myCharacter)
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m?accessuid=\(id)")
                print("==url==",url!)
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "POST"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 M POST 2")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //改大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("改大頭照 P PUT 2-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()
            }
            
        }else if Exist_P == 1 && Exist_M == -1{
            //已是攝影師
            if myCharacter == "攝影師"{
                //PUT資料修改
                let postdata:[String: Any] = ["ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p?uid=\(id)&accessuid=\(id)")
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "PUT"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 P PUT 3")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //改大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("改大頭照 P PUT 3-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()

                
                
            }else if myCharacter == "模特兒"{
                //POST
                let postdata:[String: Any] = ["ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m?uid=\(id)&accessuid=\(id)")
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "POST"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 M POST 4")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //改大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("改大頭照 P PUT 4-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()
            }
            
        }else if Exist_P == -1 && Exist_M == 1{
            //已是模特兒
            if myCharacter == "攝影師"{
                //POST
                let postdata:[String: Any] = ["ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p?uid=\(id)&accessuid=\(id)")
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "POST"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 P POST 5")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //改大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("改大頭照 P PUT 5-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()
                
            }else if myCharacter == "模特兒"{
                //PUT
                let postdata:[String: Any] = ["ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m?uid=\(id)&accessuid=\(id)")
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "PUT"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 M PUT 6")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //PUT大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 M PUT 6-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()

                
            }
        }else if Exist_P == 1 && Exist_M == 1{
            //用 PUT
            if myCharacter == "攝影師"{
                let postdata:[String: Any] = ["ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p?uid=\(id)&accessuid=\(id)")
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "PUT"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 P PUT 7")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //PUT大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 P PUT 7-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()
            }else if myCharacter == "模特兒"{
                //用 PUT
                let postdata:[String: Any] = ["ShowName":"\(myName as! String)","Phone":"\(myPhone as! String)","WorkLocation":"\(myLocation as! String)"]
                
                let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m?uid=\(id)&accessuid=\(id)")
                let config = URLSessionConfiguration.default
                let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
                var request = URLRequest(url: url!)
                
                request.httpMethod = "PUT"
                request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
                
                guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
                request.httpBody = httpbody
                
                let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)
                        
                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 M PUT 8")
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask.resume()
                
                //PUT大頭照
                let postdata2:[String: Any] = ["UserId":"\(id)","ProfileUrl":"\(profile as! String)"]

                let url2 = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?accessuid=\(id)")
                let config2 = URLSessionConfiguration.default
                let session2 = URLSession(configuration: config2, delegate: nil, delegateQueue: nil)
                var request2 = URLRequest(url: url2!)

                request2.httpMethod = "PUT"
                request2.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")

                guard let httpbody2 = try? JSONSerialization.data(withJSONObject: postdata2, options: []) else {return}
                request2.httpBody = httpbody2

                let dataTask2 = session2.dataTask(with: request2, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                    if let response = response{
                        print(response)

                    }
                    if let data = data{
                        do{
                            let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                            print(json)
                            print("完成 M PUT 8-2")
                            print("===看這邊===",self.myPhone,self.myLocation,self.profile)
                            DispatchQueue.main.async {
                                let alertView = UIAlertController.init(title: "編輯完成!", message: "", preferredStyle: .alert)
                                self.present(alertView, animated: true, completion: nil)
                                self.presentedViewController?.dismiss(animated: false, completion: nil)
                                
                            }
                        }catch{
                            print(error)
                        }
                    }
                })
                dataTask2.resume()
            }
        }
    }
    

    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0
        
        
        if textField.tag == 1{
            shift = 60.0
        }else if textField.tag == 2{
            shift = 120.0
        }
        
        
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y - shift)
    }
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0
        
        
        if textField.tag == 1{
            shift = 60.0
        }else if textField.tag == 2{
            shift = 120.0
        }
        
        
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y + shift)
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        txt姓名.resignFirstResponder()
        txt電話.resignFirstResponder()
        txt地區.resignFirstResponder()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        
        
    }
    
    
    
    @IBAction func btn上傳照片_Click(_ sender: Any) {
        let myImagePicker:UIImagePickerController = UIImagePickerController()
        
        myImagePicker.delegate = self //＊＊＊一定要設
        
        myImagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        self.present(myImagePicker,animated: true,completion: nil)
    }
    
    

    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
                let storageRef = Storage.storage().reference().child("pic")
        
        //info[放入key]是個字典 註：key有很多種可選 EX:UIImagePickerControllerOriginalImage,UIImagePickerControllerImageURL...
        
        let tookImage:UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage //將選的原始圖檔 轉為UIImage
        
        
        self.myImageView.image = tookImage
        
        // 設定上傳檔案名
        var filename = "image.JPG"
        if let url = info[UIImagePickerControllerImageURL] as? URL{
            filename = url.lastPathComponent //url最後一個Component就是檔案名稱
            print("==這是檔案名稱==",filename)
            UserDefaults.standard.set(filename, forKey: "UPload_fileName")
            UserDefaults.standard.synchronize()
        }
        
        
        if let theUid = UserDefaults.standard.value(forKey: "thisId") as? String{
            if let data = UIImageJPEGRepresentation(tookImage, 0.1){ //UIImageJPEGRepresentation(設壓縮比)
                
                //建立中介資料
                let myMetadata = StorageMetadata()
                
                myMetadata.contentType = "image/jpeg" //***轉為圖擋
                
                myMetadata.customMetadata = ["myKey":"myValue"]
                
                
                //＊＊＊上傳 子目錄：第一層為使用者Id  第二層為檔案名稱  putData上傳檔案
                let task = storageRef.child(theUid).child(filename).putData(data, metadata: myMetadata) { (metadata, error) in
                    
                    
                    if  error == nil{
                        
                        //若上傳成功
                        let dataRef = Database.database().reference().child("pic")
                        
                        storageRef.child(theUid).child(filename).downloadURL(completion: {
                            
                            (url, error) in
                            
                            if error != nil {
                                
                                return
                            } else {
                                
                                let url = url?.absoluteString //＊＊＊取得URL的字串
                                
                                let value = ["uid":theUid,"link":url]
                                
                                dataRef.childByAutoId().setValue(value)
                                
                                let uploaderID = theUid
                                
                                //寫入Server
                                let newURL = APIFactory().postPhotoToDatabase(uploaderId: uploaderID, firebaseURL:url!)
                                self.profile = newURL
                                print("==最新url==",newURL)
                            }
                        })
                        
                        let firebaseURL = self.appDelegate.strFirebaseURL
                        print("==測試用firebaseURL=",firebaseURL)
                        
                    }else{
                        //若上傳失敗 印出錯誤
                        print(error?.localizedDescription)
                    }
                }
                
            }
        }
        picker.dismiss(animated: true, completion: nil) //將picker關閉
        
    }
    
    //取消選取
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btn相機_Click(_ sender: Any) {

        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let myImagePicker:UIImagePickerController = UIImagePickerController()
            myImagePicker.sourceType = UIImagePickerControllerSourceType.camera
            myImagePicker.delegate = self //＊＊＊一定要設
            show(myImagePicker,sender: self)
        }
 
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        txt姓名.becomeFirstResponder()
        txt電話.becomeFirstResponder()
        txt地區.becomeFirstResponder()
        txt姓名.delegate = self
        txt地區.delegate = self
        txt電話.delegate = self
        
        speechRecognizer.delegate = self
        // 語音識別權限請求
        SFSpeechRecognizer.requestAuthorization { (authStatus) in
            switch authStatus {
            case .authorized:
                // 通過授權
                self.micButtonEnabled = true
                break
            case .denied:
                // 拒絕授權
                self.micButtonEnabled = false
                break
            case .restricted:
                // 權限受限制
                self.micButtonEnabled = false
                break
            case .notDetermined:
                // 權限不明確
                self.micButtonEnabled = false
                break
            }
        }
        
        id = UserDefaults.standard.value(forKey: "thisId") as! String
        
        print("==目前ID==",id)
        
        DispatchQueue.main.async {
            self.strData_Info = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p?id=\(self.id)") //取得p所有資料
            self.strData_Info2 = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m?id=\(self.id)") //取得m所有資料
            self.strData_Info3 = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?id=\(self.id)") //取得user所有資料
            sleep(1)
            self.myName = APIFactory_2().parseEditName(data: self.strData_Info3!)//解析姓名
            
            self.Exist_P = APIFactory_3().parseExist(data: self.strData_Info!)
            self.Exist_M = APIFactory_3().parseExist(data: self.strData_Info2!)
            print("==exist==" ,self.Exist_M,self.Exist_P)

            //顯示彩球
            self.displayActivityIndicator()
            self.activityIndicator.isHidden = false
        }
        
        
        OperationQueue.main.addOperation{
            if self.Exist_P == 1 && self.Exist_M == -1{
                //已為攝影師
                self.myGender = APIFactory_2().parseEditGender(data: self.strData_Info3!)//解析性別 回傳M/F
                self.myCharacter = "攝影師"
                self.seg角色.selectedSegmentIndex = 1
                self.profile = APIFactory_2().parseProfile(data: self.strData_Info3!)
                self.myPhone = APIFactory_2().parseEditPhone(data:self.strData_Info!)
                self.myLocation = APIFactory_2().parseEditLocation(data:self.strData_Info!)
                print("===已為攝影師！！===")
                
                
            }else if self.Exist_P == -1 && self.Exist_M == 1{
                //已為模特兒
                self.myGender = APIFactory_2().parseEditGender(data: self.strData_Info3!)//解析性別 回傳M/F
                self.myCharacter = "模特兒"
                self.seg角色.selectedSegmentIndex = 2
                self.profile = APIFactory_2().parseProfile(data: self.strData_Info3!)
                self.myPhone = APIFactory_2().parseEditPhone(data:self.strData_Info2!)
                self.myLocation = APIFactory_2().parseEditLocation(data:self.strData_Info2!)
                print("===已為模特兒！！===")
            }else if self.Exist_P == -1 && self.Exist_M == -1{
                //尚未決定角色
                self.myGender = APIFactory_2().parseEditGender(data: self.strData_Info3!)//解析性別 回傳M/F
                self.myCharacter = "無"
                self.seg角色.selectedSegmentIndex = 0
                self.profile = APIFactory_2().parseProfile(data: self.strData_Info3!)
                print("===尚未決定角色===")
            }
            
            if let url = URL(string:self.profile){
                let downloadTask = URLSession.shared.dataTask(with: url){
                    (data,response,error) in
                    guard let imageData = data else {return}
                    OperationQueue.main.addOperation{
                        guard let image = UIImage(data: imageData) else {return}
                        
                        self.myImageView.image = image
                        
                        
                        self.myImageView.layer.masksToBounds = true
                        self.myImageView.layer.cornerRadius = 40
                        CacheManager.shared.cache(object: image, key: self.profile)
                    }
                }
                downloadTask.resume()
            }
            self.txt姓名.text = self.myName
            if self.myGender == "M"{
                self.seg性別.selectedSegmentIndex = 0
            }else if self.myGender == "F"{
                self.seg性別.selectedSegmentIndex = 1
            }else{
                self.seg性別.selectedSegmentIndex = 0
            }
            self.txt電話.text = self.myPhone ?? ""
            self.txt地區.text = self.myLocation ?? ""
            
            //停止彩球
            self.activityIndicator.stopAnimating()
            self.messageFrame.removeFromSuperview()
            self.activityIndicator.hidesWhenStopped = true //停下時 彩球自動隱藏

        }
    }

    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        //顯示彩球
        self.displayActivityIndicator()
        self.activityIndicator.isHidden = false
        
    }
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        
        //停止彩球
        self.activityIndicator.stopAnimating()
        self.messageFrame.removeFromSuperview()
        self.activityIndicator.hidesWhenStopped = true //停下時 彩球自動隱藏

    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        AVAudioSession.sharedInstance().requestRecordPermission { (permiss:Bool) in
            self.micButtonEnabled = permiss
        }
    }
    
    
    func startRecording(){
        
        if !audioEngine.isRunning {
            recordResult = ""
            recording()
            
        }
        
    }
    
    
    func stopRecording(){
        if (recognitionRequest != nil) {
            recognitionRequest?.endAudio()
        }
    }
    
    
    func recording() {
        
        if recognitionTask != nil {
            recognitionTask?.cancel()
            recognitionTask = nil
        }
        do {
            
            try audioSession.setCategory(AVAudioSessionCategoryRecord)
            try audioSession.setMode(AVAudioSessionModeMeasurement)
            try audioSession.setActive(true, with: .notifyOthersOnDeactivation)
        } catch {
            print("audioSession properties weren't set because of an error.")
        }
        
        recognitionRequest = SFSpeechAudioBufferRecognitionRequest()
        
        let inputNode = audioEngine.inputNode
        
        guard let recognitionRequest = recognitionRequest else {
            fatalError("Unable to create an SFSpeechAudioBufferRecognitionRequest object")
        }
        recognitionRequest.shouldReportPartialResults = true
        
        recognitionTask = speechRecognizer.recognitionTask(with: recognitionRequest, delegate: self)
        
        
        let recordingFormat = inputNode.outputFormat(forBus: 0)
        
        
        inputNode.installTap(onBus: 0, bufferSize: 1024, format: recordingFormat) { (buffer, when) in
            self.recognitionRequest?.append(buffer)
        }
        audioEngine.prepare()
        do {
            
            try audioEngine.start()
        } catch {
            print("audioEngine couldn't start because of an error.")
        }
    }
    
    /******* 以下都是代理方法 *******/
    
    
    func speechRecognizer(_ speechRecognizer: SFSpeechRecognizer, availabilityDidChange available: Bool) {

    }
    
    
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didHypothesizeTranscription transcription: SFTranscription) {
        
        if(timer != nil && timer.isValid){
            timer.invalidate()
            timer = nil
        }
        timer = Timer.scheduledTimer(withTimeInterval: 2, repeats: true, block: { (Timer) in
            self.stopRecording()
        })
       
    }
    
    
    func speechRecognitionTaskFinishedReadingAudio(_ task: SFSpeechRecognitionTask) {
        
    }
    
    
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishRecognition recognitionResult: SFSpeechRecognitionResult) {
        print(recognitionResult)
        recordResult = recognitionResult.bestTranscription.formattedString
    }
    
    
    func speechRecognitionTask(_ task: SFSpeechRecognitionTask, didFinishSuccessfully successfully: Bool){
        
        
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
        self.recognitionRequest = nil
        self.recognitionTask = nil
        do {
            
            try audioSession.setCategory(AVAudioSessionCategoryAmbient)
        }catch let error as NSError{
            print(error.code)
        }
        if(timer != nil){
            timer.invalidate()
            timer = nil
        }
        
        txt地區.text = recordResult
        
        
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
