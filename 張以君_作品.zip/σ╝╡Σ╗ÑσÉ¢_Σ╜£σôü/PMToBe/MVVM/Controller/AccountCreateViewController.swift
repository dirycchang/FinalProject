//
//  AccountCreateViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/28.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase

class AccountCreateViewController: UIViewController,UITextFieldDelegate{
    
    
    @IBAction func btn立刻登入_Click(_ sender: Any) {
        
        let LoginVC:LoginViewController = self.storyboard?.instantiateViewController(withIdentifier: "login") as! LoginViewController
        self.present(LoginVC, animated: true, completion: nil)
    }
    //////寫入firebase
    var ref:DatabaseReference? = nil
    var myGender:String = ""
    var myCharacter:String = ""
    
    
    @IBOutlet weak var lbl信箱: UILabel!
    @IBOutlet weak var txt信箱: UITextField!
  
    @IBOutlet weak var lbl帳號: UILabel!
    @IBOutlet weak var lbl密碼: UILabel!
    @IBOutlet weak var lbl姓名: UILabel!
    @IBOutlet weak var lbl性別: UILabel!
    @IBOutlet weak var txt帳號: UITextField!
    @IBOutlet weak var txt密碼: UITextField!
    @IBOutlet weak var txt姓名: UITextField!

    
    @IBAction func seg性別_ValueChanged(_ sender: UISegmentedControl) {
        
        if sender.selectedSegmentIndex == 0{
            if let gender = sender.titleForSegment(at: 0){
                myGender = gender
                print(myGender)
            }
        }else if sender.selectedSegmentIndex == 1{
            if let gender = sender.titleForSegment(at: 1){
                myGender = gender
                print(myGender)
            }
        }
        
    }
    
//    @IBAction func seg角色_ValueChanged(_ sender: UISegmentedControl) {
//
//        if sender.selectedSegmentIndex == 0{
//            if let character = sender.titleForSegment(at: 0){
//                myCharacter = character
//                print(myCharacter)
//            }
//        }else if sender.selectedSegmentIndex == 1{
//            if let character = sender.titleForSegment(at: 1){
//                myCharacter = character
//                print(myCharacter)
//            }
//        }else if sender.selectedSegmentIndex == 2{
//            if let character = sender.titleForSegment(at: 2){
//                myCharacter = character
//                print(myCharacter)
//            }
//        }
//    }
    
    
    //寫入資料庫
    @IBAction func btn完成_Selected(_ sender: UIButton) {
        
        
        
        let postdata:[String: Any] = ["USername":"\(txt帳號.text as! String)","Name":"\(txt姓名.text as! String)","Email":"\(txt信箱.text as! String)","Password":"\(txt密碼.text as! String)","Gender":"\(myGender)"]
        
        let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/register")
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "POST"
        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
        request.httpBody = httpbody
        
        
        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            if let response = response{
                print(response)
            }
            
            if let data = data{ //body裡面的東西
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                    print(json)
                    
                    
                    if let result = json["result"] as? Int{

                        if result == 1{
                            
                       DispatchQueue.main.async {
                                self.txt密碼.resignFirstResponder()
                                self.txt帳號.resignFirstResponder()
                                self.txt姓名.resignFirstResponder()
                                self.txt信箱.resignFirstResponder()
                                
                                self.view.resignFirstResponder()
                                
                                let alertView = UIAlertController.init(title: "註冊成功！", message: "", preferredStyle: .alert)
                                alertView.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
                                self.present(alertView, animated: true, completion: nil)
                                
                                // 呈現主視圖
                                if let viewController = self.storyboard?.instantiateViewController(withIdentifier: "login") {
                                    UIApplication.shared.keyWindow?.rootViewController = viewController
                                    self.dismiss(animated: true, completion: nil)
                                }
                            }
                        }else{
                            print("登入失敗")
                        }
                    }
                    
                }catch{
                    print(error)
                }
            }
        })
        dataTask.resume()
    }
    
    ///////////

    
    @IBOutlet weak var myPickerView: UIPickerView!
    

    

    
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0
        
        
        if textField.tag == 3{
            shift = 90.0
        }else if textField.tag == 4{
            shift = 120.0
        }
        
        
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y - shift)
    }
    
    
    
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
        var shift:CGFloat = 0.0
        
        if textField.tag == 3{
            shift = 90.0
        }else if textField.tag == 4{
            shift = 120.0
        }
        
        
        self.view.center = CGPoint(x: self.view.center.x, y: self.view.center.y + shift)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        txt姓名.resignFirstResponder()
        txt信箱.resignFirstResponder()
        txt帳號.resignFirstResponder()
        txt密碼.resignFirstResponder()
    }
    
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
    }
    
    

    override func viewDidLoad() {
        
        super.viewDidLoad()
        

        ref = Database.database().reference().child("users")
    }

    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
