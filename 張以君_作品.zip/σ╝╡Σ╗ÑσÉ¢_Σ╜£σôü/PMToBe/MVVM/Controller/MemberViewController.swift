//
//  MemberViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/28.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn
import FirebaseAuth
import MessageUI

class MemberViewController: UIViewController, MFMailComposeViewControllerDelegate  {

    
    @IBAction func btn登出_Click(_ sender: UIButton) {
        let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/logout")
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "POST"
        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            if let response = response{
                print("這是回應==============:")
                print(response)
            }
            
            if let data = data{ //body裡面的東西
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                    print("以下這是JSON==============:")
                    print(json)
                    print("以下這是result==============:")
                    print(json["result"]!)
                    
                    if let result = json["result"] as? Int{
                        if result == 1{
                            DispatchQueue.main.async {
                                
                                let alertView = UIAlertController.init(title: "成功登出", message: "", preferredStyle: .alert)
                                alertView.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
                                self.present(alertView, animated: true, completion: nil)
                                // 呈現主視圖
                                if let viewController = self.storyboard?.instantiateViewController(withIdentifier: "firstVC") {
                                    UIApplication.shared.keyWindow?.rootViewController = viewController
                                    self.dismiss(animated: true, completion: nil)
                                }
                            }
                            
                        }
                    }
                }catch{
                    print("以下這是錯誤==============:")
                    print(error)
                }
            }
        })
        dataTask.resume()
    }
    
    
    
    
    
    
    
    @IBAction func btn聯絡我們_Click(_ sender: UIButton) {
        let mailComposeViewController = configuredMailComposeViewController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            self.showSendMailErrorAlert()
        }
    }
    
    func configuredMailComposeViewController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self // Extremely important to set the --mailComposeDelegate-- property, NOT the --delegate-- property
        
        mailComposerVC.setToRecipients(["iiiteam102@gmail.com"])
        mailComposerVC.setSubject("PMToBe真是攝影界夢想的橋樑")
        mailComposerVC.setMessageBody("第一次用PM To Be就上手，且當天就找到合適的夥伴了。真是太棒了！！ By愛慕者 ", isHTML: false)
        
        return mailComposerVC
    }
    
    func showSendMailErrorAlert() {
        let sendMailErrorAlert = UIAlertController(title: "無法發送電子郵件", message: "您的設備無法發送電子郵件。請檢查電子郵件配置，然後重試。", preferredStyle: UIAlertControllerStyle.alert)
        sendMailErrorAlert.show(sendMailErrorAlert, sender: nil)
    }
    
    // MARK: MFMailComposeViewControllerDelegate Method
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    
    
    @IBAction func btn版本_Click(_ sender: UIButton) {
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now()) {
            let alertView = UIAlertController.init(title: "PMToBe 2.0版本", message: "", preferredStyle: .alert)
            self.present(alertView, animated: true, completion: nil)
            self.presentedViewController?.dismiss(animated: false, completion: nil)
        }
    }
    
    //登出

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
