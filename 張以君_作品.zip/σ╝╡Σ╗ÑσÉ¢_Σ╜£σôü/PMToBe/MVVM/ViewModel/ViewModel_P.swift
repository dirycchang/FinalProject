//
//  ViewModel_P.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

struct ViewModel_P {
    
//    let title: String
//    let imageURL: String
//    let releaseDate: String
//    let purchasePrice: String
//    let summary: String
    
    //let data: String
    let UserId: Int
    let UserName: String
    let ShowName: String
    let ProfileUrl: String
    let PhotoType: String
    let Location: String
    let Introduction: String
    let AcceptStyle: String
    let Gender: String
    let Phone: String
    let Email:String
    
    init(model: pStruct) {
        self.UserId = model.UserId
        //self.title = model.title.uppercased()
        self.ProfileUrl = model.ProfileUrl
        self.UserName = model.UserName
        self.ShowName = model.ShowName
        self.PhotoType = model.PhotoType
        self.Location = model.Location
        self.Introduction = model.Introduction
        self.AcceptStyle = model.AcceptStyle
        self.Gender = model.Gender
        self.Phone = model.Phone
        self.Email = model.Email
        
    }
}

