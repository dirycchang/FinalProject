//
//  Cell_P.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/18.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class Cell_P: UITableViewCell {
    
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    
    let P_Image: UIImageView = {
        let iv = UIImageView()
        iv.contentMode = .scaleAspectFill
        iv.layer.cornerRadius = 40
        iv.backgroundColor = #colorLiteral(red: 0, green: 0.5898008943, blue: 1, alpha: 1)
        iv.translatesAutoresizingMaskIntoConstraints = false
        iv.clipsToBounds = true
        return iv
    }()
    
    let P_NameLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let P_LocationLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.caption1)
        l.textAlignment = .left
        l.textColor = .white
        return l
    }()
    
    let P_StyleLabel: UILabel = {
        let l = UILabel()
        l.numberOfLines = 0
        l.translatesAutoresizingMaskIntoConstraints = false
        l.font = UIFont.preferredFont(forTextStyle: UIFontTextStyle.headline)
        l.textAlignment = .right
        l.textColor = .white
        return l
    }()
    
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        setUpViews()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func setUpViews() {
        backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        addSubview(P_Image)
        P_Image.widthAnchor.constraint(equalToConstant: 80).isActive = true
        P_Image.heightAnchor.constraint(equalToConstant: 80).isActive = true
        P_Image.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        P_Image.leftAnchor.constraint(equalTo: leftAnchor, constant: 10).isActive = true
        
        addSubview(P_StyleLabel)
        P_StyleLabel.widthAnchor.constraint(equalToConstant: 100).isActive = true
        P_StyleLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        P_StyleLabel.rightAnchor.constraint(equalTo: rightAnchor, constant: -10).isActive = true
        P_StyleLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        
        addSubview(P_NameLabel)
        P_NameLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        P_NameLabel.leftAnchor.constraint(equalTo: P_Image.rightAnchor, constant: 10).isActive = true
        P_NameLabel.rightAnchor.constraint(equalTo: P_StyleLabel.leftAnchor, constant: -10).isActive = true
        P_NameLabel.centerYAnchor.constraint(equalTo: centerYAnchor).isActive = true
        
        addSubview(P_LocationLabel)
        P_LocationLabel.heightAnchor.constraint(equalToConstant: 25).isActive = true
        P_LocationLabel.leftAnchor.constraint(equalTo: P_NameLabel.leftAnchor).isActive = true
        P_LocationLabel.rightAnchor.constraint(equalTo: P_NameLabel.rightAnchor).isActive = true
        P_LocationLabel.topAnchor.constraint(equalTo: P_NameLabel.bottomAnchor).isActive = true
        
    }
    
    func displayMovieInCell(using viewModel: ViewModel_P) {
        
        P_NameLabel.text = viewModel.ShowName
        P_LocationLabel.text = viewModel.Location
        P_StyleLabel.text = viewModel.PhotoType
        let myId = String(viewModel.UserId)
            appDelegate.strID_P.append(myId)

        appDelegate.strName_P.append(viewModel.ShowName)
        appDelegate.strStyle_P.append(viewModel.PhotoType)
        appDelegate.strLocation_P.append(viewModel.Location)
        appDelegate.strIntroduction_P.append(viewModel.Introduction)
        appDelegate.strPhone_P.append(viewModel.Phone)
        appDelegate.strProfile_P.append(viewModel.ProfileUrl)
        appDelegate.strGender_P.append(viewModel.Gender)
        

        P_Image.loadImageUsingCacheWithURLString(viewModel.ProfileUrl, placeHolder: nil) { (bool) in
            //perform actions if needed
        }
    }
}

