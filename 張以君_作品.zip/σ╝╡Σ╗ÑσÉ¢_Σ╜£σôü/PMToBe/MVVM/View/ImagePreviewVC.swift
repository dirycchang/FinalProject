//
//  ImagePreviewVC.swift
//  PMToBe
//
//  Created by Yi Chun on 2017/1/11.
//  Copyright © 2017年 YiChun. All rights reserved.
//

import UIKit


class ImagePreviewVC: UIViewController {
    
    
    var images:[String]
    
    
    var index:Int
    
    
    var collectionView:UICollectionView!
    
    var collectionViewLayout: UICollectionViewFlowLayout!
    
    
    var pageControl : UIPageControl!
    
//    let myFrame:CGRect = CGRect(x: 90.0, y: 300.0, width: 195.0, height: 350.0)
    
    init(images:[String], index:Int = 0){
        self.images = images
        self.index = index
        
        super.init(nibName: nil, bundle: nil)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    //初始化
    override func viewDidLoad() {
        super.viewDidLoad()
        

        self.view.backgroundColor = UIColor.black
        
        collectionViewLayout = UICollectionViewFlowLayout()
        collectionViewLayout.minimumLineSpacing = 0
        collectionViewLayout.minimumInteritemSpacing = 0
        
        collectionViewLayout.scrollDirection = .horizontal
        
        collectionView = UICollectionView(frame: CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height), collectionViewLayout: collectionViewLayout)
        collectionViewLayout.scrollDirection = UICollectionViewScrollDirection.horizontal
        collectionView.backgroundColor = UIColor.black
        collectionView.register(ImagePreviewCell.self, forCellWithReuseIdentifier: "cell")
        collectionView.delegate = self
        collectionView.dataSource = self
        collectionView.isPagingEnabled = true
        
        if #available(iOS 11.0, *) {
            collectionView.contentInsetAdjustmentBehavior = .never
        } else {
            self.automaticallyAdjustsScrollViewInsets = false
        }
        self.view.addSubview(collectionView)
        
        let indexPath = IndexPath(item: index, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .left, animated: false)
        
        
        pageControl = UIPageControl()
        pageControl.center = CGPoint(x: UIScreen.main.bounds.width/2,
                                     y: UIScreen.main.bounds.height - 20)
        pageControl.numberOfPages = images.count
        pageControl.isUserInteractionEnabled = false
        pageControl.currentPage = index
        view.addSubview(self.pageControl)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.navigationController?.setNavigationBarHidden(true, animated: false)
    }
 
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.navigationController?.setNavigationBarHidden(false, animated: false)
    }
    
    
    override var prefersStatusBarHidden: Bool {
        return true
    }
    

    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()

        
        collectionView.frame.size = self.view.bounds.size
        collectionView.collectionViewLayout.invalidateLayout()
        
        
        let indexPath = IndexPath(item: self.pageControl.currentPage, section: 0)
        collectionView.scrollToItem(at: indexPath, at: .left, animated: false)
        
        
        pageControl.center = CGPoint(x: UIScreen.main.bounds.width/2,
                                     y: UIScreen.main.bounds.height - 20)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
}


extension ImagePreviewVC:UICollectionViewDelegate, UICollectionViewDataSource,
    UICollectionViewDelegateFlowLayout{
    
    
    func collectionView(_ collectionView: UICollectionView,
                        cellForItemAt indexPath: IndexPath)
        -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell",
                                            for: indexPath) as! ImagePreviewCell
            if let url = URL(string:self.images[indexPath.row]){
                let downloadTask = URLSession.shared.dataTask(with: url){
                    (data,response,error) in
                    guard let imageData = data else {return}
                    OperationQueue.main.addOperation{
                        guard let image = UIImage(data: imageData) else {return} //將imageData轉為UIImage 就繼續往下執行 否則return
                        //加圖片至快取
                        cell.imageView.image = image
                        cell.layer.masksToBounds = true
                        cell.layer.cornerRadius = 5
                        
                        CacheManager.shared.cache(object: image, key: self.images[indexPath.row])
                    }
                }
                downloadTask.resume()
            }
        return cell
    }
    
   
    func collectionView(_ collectionView: UICollectionView,
                        numberOfItemsInSection section: Int) -> Int {
        return self.images.count
    }
    
    
    func collectionView(_ collectionView: UICollectionView,
                        layout collectionViewLayout: UICollectionViewLayout,
                        sizeForItemAt indexPath: IndexPath) -> CGSize {
        return self.view.bounds.size
    }
    
    
    func collectionView(_ collectionView: UICollectionView,
                        willDisplay cell: UICollectionViewCell,
                        forItemAt indexPath: IndexPath) {
        if let cell = cell as? ImagePreviewCell{
            
            cell.resetSize()
        }
    }
    
    
    func collectionView(_ collectionView: UICollectionView,
                        didEndDisplaying cell: UICollectionViewCell,
                        forItemAt indexPath: IndexPath) {
        
        let visibleCell = collectionView.visibleCells[0]
        
        self.pageControl.currentPage = collectionView.indexPath(for: visibleCell)!.item
    }
}


