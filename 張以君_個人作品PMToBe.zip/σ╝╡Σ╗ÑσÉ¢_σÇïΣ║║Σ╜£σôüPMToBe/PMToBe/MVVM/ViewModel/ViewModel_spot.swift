//
//  ViewModel_spot.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/22.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

struct ViewModel_spot {
    
    let Id : Int
    let Name: String
    let Address: String
    let Description: Any
    let PosX: Any
    let PosY: Any
    let GUID: String
    
    init(model: spotStruct) {
        //self.title = model.title.uppercased()
        self.Id = model.Id
        self.Name = model.Name
        self.Address = model.Address
        self.Description = model.Description
        self.PosX = model.PosX
        self.PosY = model.PosY
        self.GUID = model.GUID
     
    }
}


