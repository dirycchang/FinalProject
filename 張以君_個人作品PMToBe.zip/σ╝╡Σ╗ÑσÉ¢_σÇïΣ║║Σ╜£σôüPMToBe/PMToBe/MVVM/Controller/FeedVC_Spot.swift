//
//  FeedVC_Spot.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/22.
//  Copyright © 2018年 YiChun. All rights reserved.
//
import Foundation
import UIKit
import MapKit
import CoreLocation

class FeedVC_Spot:UIViewController ,MKMapViewDelegate,CLLocationManagerDelegate,UITableViewDelegate,UITableViewDataSource,UISearchResultsUpdating{
    
    
    @IBOutlet weak var btnZoomIn: UIBarButtonItem!
    @IBOutlet weak var btnZoomOut: UIBarButtonItem!
    @IBOutlet weak var mapView_SpotList: MKMapView!
    @IBOutlet weak var tableView: UITableView!
    
    //variables
    var mapScaleMeter:Double=1000.0
    var myLocationManager:CLLocationManager!
    
    var strSpotData:Data?
    
    var arraySpotId:[String] = []
    var arraySpotName:[String] = []
    var arraySpotAddress:[String] = []
    var arraySpotDescription:[String] = []
    var arraySpotPosX:[String] = []
    var arraySpotPosY:[String] = []
    var arraySpotGUID:[String] = []
    var searchedSpot = [String]()
    var mySearchController: UISearchController!
    
    private let cellID = "cellID"
    let service = Service_Spot()
    
    var searchAdv = [spotStruct]() //篩選模仿結構
    
    var spotArray = [spotStruct]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    @IBAction func btnZoomIn_Click(_ sender: Any) {
        
        self.mapScaleMeter *= 1.5
        let userLocation:MKUserLocation=self.mapView_SpotList.userLocation
        let region:MKCoordinateRegion=MKCoordinateRegionMakeWithDistance(userLocation.coordinate, self.mapScaleMeter,self.mapScaleMeter )
        self.mapView_SpotList.setRegion(region, animated: false)
    }
    
    @IBAction func btnZoomOut_Click(_ sender: Any) {
        
        self.mapScaleMeter *= 2.5
        let userLocation:MKUserLocation=self.mapView_SpotList.userLocation
        let region:MKCoordinateRegion=MKCoordinateRegionMakeWithDistance(userLocation.coordinate, self.mapScaleMeter,self.mapScaleMeter )
        self.mapView_SpotList.setRegion(region, animated: false)
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        let myLocation:CLLocation=locations.last!
        //        print("\(myLocation.coordinate.longitude)","\(myLocation.coordinate.latitude)")
        
    }

    
    func addLandmark(){

        for i in 0..<arraySpotPosY.count{
            let strPosY:String=arraySpotPosY[i]
            let doublePosY=(strPosY as NSString).doubleValue

            let strPosX:String=arraySpotPosX[i]
            let doublePosX=(strPosX as NSString).doubleValue

            print(doublePosX,"doublePosX")
            print(doublePosY,"doublePosY")
            //開始插旗子
            var myAutoFlag:CLLocationCoordinate2D=CLLocationCoordinate2D()
            myAutoFlag.longitude=doublePosX
            myAutoFlag.latitude=doublePosY
            print(myAutoFlag.latitude,"====myAutoFlag.latitude==")
            print(myAutoFlag.longitude,"=======myAutoFlag.longitude======")


            let myAutoFlagAnno:MKPointAnnotation = MKPointAnnotation()
            myAutoFlagAnno.coordinate=myAutoFlag
            myAutoFlagAnno.title=arraySpotName[i]
            print(myAutoFlagAnno.title!,"=====myAutoFlagAnno.title=======")


            self.mapView_SpotList.addAnnotation(myAutoFlagAnno)

        }

    }
    
    func mapView(_ mapView: MKMapView, viewFor annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation is MKUserLocation
        {
            //user location style cannot change otherwise the program will froze
            //"is"-->是用來判斷是否是相同類別
            return nil
        }
            
        else
        {
            let annView:MKAnnotationView=MKAnnotationView(annotation: annotation, reuseIdentifier: "myannot")
            
            annView.canShowCallout=true
            
            let btnInfo:UIButton = UIButton(type: UIButtonType.infoLight)
            
            btnInfo.addTarget(self, action: #selector(showDetailView(_:)), for: UIControlEvents.touchUpInside)
            annView.rightCalloutAccessoryView = btnInfo
            
            let myIcon:UIImageView=UIImageView(image: UIImage(named: "pin.png"))
            annView.leftCalloutAccessoryView = myIcon
            
            return nil
        }
    }
    
    @IBAction func showDetailView(_ sender: Any) {
        print("~~~open~~~")
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.backgroundColor = #colorLiteral(red: 0.2549019754, green: 0.2745098174, blue: 0.3019607961, alpha: 1)
        tableView.register(Cell_Spot.self, forCellReuseIdentifier: cellID)
        tableView.contentInset = UIEdgeInsets(top: 22, left: 0, bottom: 0, right: 0)
        
        self.strSpotData=APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot")

        self.arraySpotPosY=APIFactory().parseAllSpotPosY(data: self.strSpotData!) as! [String]
        print(self.arraySpotPosY,"======spot PosY")

        self.arraySpotPosX=APIFactory().parseAllSpotPosX(data: self.strSpotData!) as! [String]
        print(self.arraySpotPosX,"========spot PosX")

        self.arraySpotName=APIFactory().parseAllSpotName(data: self.strSpotData!) as! [String]
        print(self.arraySpotName,"======spot name")
        getSpots(fromService: service)

        navigationController?.navigationBar.prefersLargeTitles = true
        let searchController = UISearchController(searchResultsController: nil)
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        navigationItem.searchController = searchController
        searchController.searchBar.searchBarStyle = .minimal
        searchController.searchBar.barTintColor = .white
        searchController.searchBar.placeholder = "請輸入景點名稱..."
        definesPresentationContext = true
       
        navigationController?.navigationBar.prefersLargeTitles = false

        self.myLocationManager=CLLocationManager()
        self.myLocationManager.delegate=self
        //best適合行人定位速度比較慢
        self.myLocationManager.desiredAccuracy=kCLLocationAccuracyBest
        self.myLocationManager.requestWhenInUseAuthorization()
        self.myLocationManager.requestAlwaysAuthorization()
        self.myLocationManager.startUpdatingLocation()
        
        self.mapView_SpotList.delegate=self
        self.mapView_SpotList.showsUserLocation=true
        
        
        //插旗子方法
        self.addLandmark()
        
        self.tableView.delegate=self
        self.tableView.dataSource=self
    }
    
    private func getSpots<S: Gettable_SPOT>(fromService service: S) where S.T == Array<spotStruct?> {
        
        service.get { [weak self] (result) in
            switch result {
            case .Success(let spots):
                var tempSpots = [spotStruct]()
                for spot in spots {
                    if let spot = spot {
                        tempSpots.append(spot)
                    }
                }
                self?.spotArray = tempSpots
                print("==spotArray內容：==",self?.spotArray)
                
            //dump(self.movies)
            case .Error(let error):
                print(error)
            }
        }
    }
    
    
    //實作觸控事件：因都是viewControl提供的 故實作時要override 注意：有四個(四種狀態) 且 全部都要實作(但未必裡面要寫程式碼)
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態1：按下去接觸到螢幕的瞬間
        //收鍵盤
        resignFirstResponder()
    }
    
    override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態2：按到且滑動時
        
    }
    override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態3：手指離開螢幕的瞬間
        
    }
    
    override func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //狀態4：手指仍在螢幕但觸控事件被中斷 ex：有電話打來
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    override var shouldAutorotate: Bool{
        return true
    }
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return UIInterfaceOrientationMask.landscapeLeft
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        
        //the screen lanscape mode
        if size.width>size.height{
            //實作打橫情況的talbe view
            
        }
    }
    
    //tableview
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //讓產生的cell可以重複使用
        let cell = tableView.dequeueReusableCell(withIdentifier: cellID) as! Cell_Spot
        //之前從沒產生cell
        
        if navigationItem.searchController?.isActive == true {
            let spot = searchAdv[indexPath.row]
            let spotViewModel = ViewModel_spot(model: spot)
            cell.displayMovieInCell(using: spotViewModel)
            
        }else {
            let spot = spotArray[indexPath.row]
            let spotViewModel = ViewModel_spot(model: spot)
            cell.displayMovieInCell(using: spotViewModel)
        }
        return cell
        

    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        if navigationItem.searchController?.isActive == true {
            return searchAdv.count
        } else {
            return spotArray.count
        }
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let theDetailVC:SpotDetailController=self.storyboard?.instantiateViewController(withIdentifier:"VCDetail") as! SpotDetailController
        
        if navigationItem.searchController?.isActive == true{
            theDetailVC.spotId = searchAdv[indexPath.row].Id
            theDetailVC.strAddress = searchAdv[indexPath.row].Address
            theDetailVC.strName = searchAdv[indexPath.row].Name
            theDetailVC.strDescription = searchAdv[indexPath.row].Description as! String
            theDetailVC.PosX=Double(searchAdv[indexPath.row].PosX as! NSNumber)
            theDetailVC.PosY=Double(searchAdv[indexPath.row].PosY as! NSNumber)
            theDetailVC.spotGUID=searchAdv[indexPath.row].GUID
            
        }else{
            
            theDetailVC.spotId=spotArray[indexPath.row].Id
            theDetailVC.strName=spotArray[indexPath.row].Name
            theDetailVC.strAddress=spotArray[indexPath.row].Address
            theDetailVC.strDescription=spotArray[indexPath.row].Description as! String
            theDetailVC.PosX=Double(spotArray[indexPath.row].PosX as! NSNumber)
            theDetailVC.PosY=Double(spotArray[indexPath.row].PosY as! NSNumber)
            theDetailVC.spotGUID=spotArray[indexPath.row].GUID
            
        }
        
        
        self.navigationController?.show(theDetailVC, sender: nil)
    }
    
    
    func updateSearchResults(for searchController: UISearchController) {
        let searchString = searchController.searchBar.text!
        
        searchAdv = spotArray.filter { (spot) -> Bool in
            return spot.Name.contains(searchString)
            // || spot.Address.contains(searchString) || (spot.Description as! String).contains(searchString)
        }
        tableView.reloadData()
    }
    override func viewWillAppear(_ animated: Bool) {
        getSpots(fromService: service)
        self.tableView.reloadData()
    }
    
    
    
//    override func viewWillAppear(_ animated: Bool) {
//
//
//        //Array清空
//        arraySpotId.removeAll()
//        arraySpotName.removeAll()
//        arraySpotGUID.removeAll()
//        arraySpotPosX.removeAll()
//        arraySpotPosY.removeAll()
//        arraySpotAddress.removeAll()
//        arraySpotDescription.removeAll()
//
//        DispatchQueue.main.async {
            //get request to get all spot list
//            self.strSpotData=APIFactory().getAllPM(url:"http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/spot")
//
//            self.arraySpotId=APIFactory().parseLocationID(data: self.strSpotData!) as! [String]
//            print(self.arraySpotName,"======spot id")
//
//            //parse json ogf what we get spot-list
//            self.arraySpotName=APIFactory().parseAllSpotName(data: self.strSpotData!) as! [String]
//            print(self.arraySpotName,"======spot name")

//            self.arraySpotGUID=APIFactory().parseAllSpotGUID(data: self.strSpotData!) as! [String]
//            print(self.arraySpotGUID,"======GUID")
//
//            self.arraySpotPosX=APIFactory().parseAllSpotPosX(data: self.strSpotData!) as! [String]
//            print(self.arraySpotPosX,"========spot PosX")
//
//            self.arraySpotPosY=APIFactory().parseAllSpotPosY(data: self.strSpotData!) as! [String]
//            print(self.arraySpotPosY,"======spot PosY")

//            self.arraySpotAddress=APIFactory().parseAllSpotAddress(data: self.strSpotData!) as! [String]
//            print(self.arraySpotAddress,"====spot address")
//
//            self.arraySpotDescription=APIFactory().parseAllSpotDescription(data: self.strSpotData!) as! [String]
//            print(self.arraySpotDescription,"======Description")
//            //ViewDidload 填入
//            self.tableView.reloadData()
//        }
//    }
}
