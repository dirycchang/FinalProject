//
//  Service_P.swift
//  PMToBe
//
//  Created by Yi Chun  on 2018/10/22.
//  Copyright © 2018 YiChun. All rights reserved.
//

import Foundation
import UIKit

//2 conform to protocol
struct Service_P: Gettable_P {

//    let QSPhotoType:String
//    let QSLocation :String
//    init(QSPhotoType PhotoType:String, QSLocation Location:String){
//        self.QSPhotoType = PhotoType
//        self.QSLocation = Location
//    }
    
    
    //3
    let endpoint: String = "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p/find"
    
    let downloader = JSONDownloader()
    
    //the associated type is inferred by <[Movie?]>
    typealias CurrentWeatherCompletionHandler = (Result<[pStruct?]>) -> ()
    
    //4 protocol required function
    func get(completion: @escaping CurrentWeatherCompletionHandler) {
        
        guard let url = URL(string: self.endpoint) else {
            completion(.Error(.invalidURL))
            return
        }
        //5 using the JSONDownloader function
        let request = URLRequest(url: url)
        let task = downloader.jsonTask(with: request) { (result) in
            
            DispatchQueue.main.async {
                switch result {
                case .Error(let error):
                    completion(.Error(error))
                    return
                case .Success(let json):
                    //6 parsing the Json response
                    guard let entryArray = json["data"] as? [[String: AnyObject]] else {
                        completion(.Error(.jsonParsingFailure))
                        return
                    }
                    //7 maping the array and create Movie objects
                    let movieArray = entryArray.map{pStruct(json: $0)}
                    completion(.Success(movieArray))
                }
            }
        }
        task.resume()
    }
}

//1 uisng associatedType in protocol
protocol Gettable_P {
    
    associatedtype T
    func get(completion: @escaping (Result<T>) -> Void)  //T：代表全部
}







