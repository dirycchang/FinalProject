//
//  ImageCollectionViewCell.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/9/9.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class ImageCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var image: UIImageView!
}
