//
//  APIFactory_2.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/13.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class APIFactory_2: NSObject{ //適用架構 {{ }}
    
    /////////////////////////////////////EditMember Api Atart//////////////////////////////////////
    
    //解析Name
    func parseEditName(data: Data) -> String{
        var resultName:String = ""
        
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["data"] as! [String:Any]
            
            let nameResult = resDict2["Username"] as! String
            
            resultName = nameResult
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultName
    }
    
    //解析性別
    func parseEditGender(data: Data) -> String{
        var resultGender:String = ""

        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["data"] as! [String:Any]
            
            let nameResult = resDict2["Gender"] as! String

            resultGender = nameResult
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultGender
    }
    
    //解析電話
    func parseEditPhone(data: Data) -> String{
        var resultEmail:String = ""
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["data"] as! [String:Any]
            
            let nameResult = resDict2["Phone"] as! String
            
            resultEmail = nameResult
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultEmail
    }
    
    //解析地區
    func parseEditLocation(data: Data) -> String{
        var resultEmail:String = ""
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["data"] as! [String:Any]
            
            let nameResult = resDict2["WorkLocation"] as! String
            
            resultEmail = nameResult
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultEmail
    }
    
    
    //會員頁面 GET大頭照
    func parseProfile(data: Data) -> String{
        var resultString:String = ""
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["data"] as! [String:Any]
            
            let nameResult = resDict2["ProfileUrl"] as! String
            
            resultString = nameResult
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultString
    }
    
    /////////////////////////////////////EditMember Api End//////////////////////////////////////
    
    //祕境GUID
    func parseGUID(data: Data) -> String{
        var resultString:String = ""
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resDict2 = resDict["data"] as! [String:Any]
            
            let nameResult = resDict2["GUID"] as! String
            
            resultString = nameResult
            
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultString
    }
    
}
