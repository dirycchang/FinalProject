//
//  EditMemberViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/11.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import FirebaseAuth

class EditMemberViewController: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate{

    
    
    @IBOutlet weak var myImageView: UIImageView!
    
    @IBOutlet weak var txt姓名: UITextField!
    @IBOutlet weak var txt電話: UITextField!
    @IBOutlet weak var txt地區: UITextField!
    
    @IBOutlet weak var seg角色: UISegmentedControl!
    @IBOutlet weak var seg性別: UISegmentedControl!
    let appDelegate: AppDelegate = UIApplication.shared.delegate as! AppDelegate
    var strData_Info:Data?
    var myName:String = "" //姓名
    var myGender:String = ""//性別
    var myEmail:String = "" //信箱
    var myCharacter:String = ""
    var id:String = ""
    var profile:String = "" //大頭照
    
    
    
    @IBAction func seg角色_ValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0{
            if let character = sender.titleForSegment(at: 0){
                myCharacter = character //無

            }
        }else if sender.selectedSegmentIndex == 1{
            if let character = sender.titleForSegment(at: 1){
                myCharacter = character //攝影師
            }
        }else if sender.selectedSegmentIndex == 2{
            if let character = sender.titleForSegment(at: 1){
                myCharacter = character //模特兒
            }
        }
    }
    
    
    @IBAction func seg性別_ValueChanged(_ sender: UISegmentedControl) {
        if sender.selectedSegmentIndex == 0{
            if let gender = sender.titleForSegment(at: 0){
                myGender = gender
                
            }
        }else if sender.selectedSegmentIndex == 1{
            if let gender = sender.titleForSegment(at: 1){
                myGender = gender
            }
        }
    }
    
    
    @IBAction func btn編輯完成_Click(_ sender: UIBarButtonItem) {
        //PUT進User
        let postdata:[String: Any] = ["UserId":"\(id as! String)","UserName":"\(txt姓名.text as! String)","Gender":"\(myGender as! String)"]
        
        let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user")
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "PUT"
        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
        request.httpBody = httpbody
        
        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            if let response = response{
                print(response)
                
            }
            if let data = data{
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                    print(json)
                    print("完成 User PUT")
                }catch{
                    print(error)
                }
            }
        })
        dataTask.resume()
        
        if myCharacter == "攝影師"{
            
            let postdata:[String: Any] = ["ShowName":"\(txt姓名.text as! String)","Phone":"\(txt電話.text as! String)","WorkLocation":"\(txt地區.text as! String)"]
           
            let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/p")
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
            var request = URLRequest(url: url!)
            request.httpMethod = "PUT"
            request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
            guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
            request.httpBody = httpbody
            
            let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                if let response = response{
                    print(response)
                }
                if let data = data{
                    do{
                        let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                        print(json)
                        print("完成 p PUT")
                    }catch{
                        print(error)
                    }
                }
            })
            dataTask.resume()
            
        }else if myCharacter == "模特兒"{
            let postdata:[String: Any] = ["ShowName":"\(txt姓名.text as! String)","Phone":"\(txt電話.text as! String)","WorkLocation":"\(txt地區.text as! String)"]
            
            let url = URL(string: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/m")
            let config = URLSessionConfiguration.default
            let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
            var request = URLRequest(url: url!)
            request.httpMethod = "PUT"
            request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
            guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return}
            request.httpBody = httpbody
            
            let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
                if let response = response{
                    print(response)
                }
                if let data = data{
                    do{
                        let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                        print(json)
                    }catch{
                        print(error)
                    }
                }
            })
            dataTask.resume()
        }
        
    }
    

    
    @IBAction func btn上傳照片_Click(_ sender: Any) {
        let myImagePicker:UIImagePickerController = UIImagePickerController()
        
        myImagePicker.delegate = self //＊＊＊一定要設
        //使用相簿
        myImagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary
        //呈現 相簿
        self.present(myImagePicker,animated: true,completion: nil)
    }
    
    
    //將選擇的照片 顯示於畫面
    //確認選取
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // 設定儲存位置 存在pic子目錄
        let storageRef = Storage.storage().reference().child("pic")
        
        //info[放入key]是個字典 註：key有很多種可選 EX:UIImagePickerControllerOriginalImage,UIImagePickerControllerImageURL...
        
        let tookImage:UIImage = info[UIImagePickerControllerOriginalImage] as! UIImage //將選的原始圖檔 轉為UIImage
        
        
        self.myImageView.image = tookImage  //註：UIImageView 的Content Mode屬性選Aspect Fit 才會比例顯示    Content Mode為所有view的共通屬性
        
        // 設定上傳檔案名
        var filename = "image.JPG"
        if let url = info[UIImagePickerControllerImageURL] as? URL{
            filename = url.lastPathComponent //url最後一個Component就是檔案名稱
            print("==這是檔案名稱==",filename)
            UserDefaults.standard.set(filename, forKey: "UPload_fileName")
            UserDefaults.standard.synchronize()
        }
        
        // 取得目前使用者 ID
        if let theUid = UserDefaults.standard.value(forKey: "thisId") as? String{
            if let data = UIImageJPEGRepresentation(tookImage, 0.1){ //UIImageJPEGRepresentation(設壓縮比)
                
                //建立中介資料
                let myMetadata = StorageMetadata()
                
                myMetadata.contentType = "image/jpeg" //***轉為圖擋
                
                myMetadata.customMetadata = ["myKey":"myValue"] //可自訂metadata 將要的資訊設在Storage中
                
                
                //＊＊＊上傳 子目錄：第一層為使用者Id  第二層為檔案名稱  putData上傳檔案
                let task = storageRef.child(theUid).child(filename).putData(data, metadata: myMetadata) { (metadata, error) in //完成時會回傳: 真正完成的metadata跟Error
                    
                    
                    if  error == nil{
                        
                        //若上傳成功
                        let dataRef = Database.database().reference().child("pic")
                        
                        storageRef.child(theUid).child(filename).downloadURL(completion: {
                            
                            (url, error) in
                            
                            if error != nil {
                                
                                return
                            } else {
                                
                                let url = url?.absoluteString //＊＊＊取得URL的字串
                                
                                let value = ["uid":theUid,"link":url]
                                
                                dataRef.childByAutoId().setValue(value)
                                
                                let uploaderID = theUid
                                
                                //寫入Server
                                let newURL = APIFactory().postPhotoToDatabase(uploaderId: uploaderID, firebaseURL:url!)
                                
                                print("==最新url==",newURL)
                            }
                        })
                        
                        let firebaseURL = self.appDelegate.strFirebaseURL
                        print("==測試用firebaseURL=",firebaseURL)
                        
                    }else{
                        //若上傳失敗 印出錯誤
                        print(error?.localizedDescription)
                    }
                }
                
            }
        }
        picker.dismiss(animated: true, completion: nil) //將picker關閉
        
    }
    
    //取消選取
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        
        picker.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func btn相機_Click(_ sender: Any) {

        if UIImagePickerController.isSourceTypeAvailable(.camera){
            let myImagePicker:UIImagePickerController = UIImagePickerController()
            myImagePicker.sourceType = UIImagePickerControllerSourceType.camera
            myImagePicker.delegate = self //＊＊＊一定要設
            show(myImagePicker,sender: self)
        }
 
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        id = UserDefaults.standard.value(forKey: "thisId") as! String
        
        strData_Info = APIFactory().getAllPM(url: "http://pmtobe-api.ap-northeast-1.elasticbeanstalk.com/api/user?id=\(id)") //取得user所有資料
        myName = APIFactory_2().parseEditName(data: strData_Info!) as! String //解析姓名
        myGender = APIFactory_2().parseEditGender(data: strData_Info!) as! String //解析性別 回傳M/F
        myEmail = APIFactory_2().parseEditEmail(data: strData_Info!) as! String //解析性別
        profile = APIFactory_2().parseProfile(data: strData_Info!) as! String
        
        if let myImgaeURL: URL = URL(string: profile){
            let myImageData: Data = try! Data(contentsOf: myImgaeURL)
            OperationQueue.main.addOperation {
                self.myImageView.image = UIImage(data: myImageData)
                CacheManager.shared.cache(object: myImageData as AnyObject, key: self.profile)
            }
        }
        
        txt姓名.text = myName
        if myGender == "M"{
            seg性別.selectedSegmentIndex = 0
        }else if myGender == "F"{
            seg性別.selectedSegmentIndex = 1
        }else{
            seg性別.selectedSegmentIndex = 0
        }

        print("這是測試",myName,myGender,myEmail)

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
