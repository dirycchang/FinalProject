//
//  APIFactory.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/10/7.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import Foundation
import UIKit

class APIFactory: NSObject{  //適用雙層架構 中間有陣列 {[{ }]}
    
    
    var strData: Data?
    
    //建立全域物件
    let appDelegate:AppDelegate = UIApplication.shared.delegate as! AppDelegate //隱含轉換成AppDelegate
    

    //GET全部
    func getAllPM(url: String) -> Data{
        
        //建立方法回傳的字串 //此方法會將非ASCII的字元轉為ASCII
        let strPerEScURL:String = url.addingPercentEncoding(withAllowedCharacters: CharacterSet.urlQueryAllowed)!
        
        ////////以下為標準流程///////(沒特別含意)
        let myURL:URL = URL(string: strPerEScURL)!
        let mySessionConfig:URLSessionConfiguration = URLSessionConfiguration.default
        let mySession:URLSession = URLSession(configuration: mySessionConfig, delegate: nil, delegateQueue: nil)
        
        //向瀏覽器請求 使用GET方法
        var myRequest = URLRequest(url:myURL)
        myRequest.httpMethod = "GET"
        
        let myDataTask = mySession.dataTask(with: myRequest, completionHandler: {
            (data:Data?, response:URLResponse?, error:Error?) -> Void in
            
            if error == nil{
                self.strData = data
  
            }else{
                print("錯誤:\(String(describing: error?.localizedDescription))")
                //return strData
            }
        })
        myDataTask.resume()
        
        sleep(1)
        return strData!
        
    }
    
    //解析JSON:GET 篩選P姓名
    func parseNameP(data: Data) -> Array<Any>{
        var resultArray:[String] = []

        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{

                let nameResult = showNamwDict["ShowName"] as! String

                resultArray.append(nameResult)

                
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    
    //解析JSON: GET 篩選M姓名
    func parseNameM(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["ShowName"] as! String
                resultArray.append(nameResult)

                
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    
    //攝影師大頭照
    func parsePpic(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["ProfileUrl"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //模特兒大頭照
    func parseMpic(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["ProfileUrl"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    
    //解析JSON GET 攝影師風格
    func parse_Pstyle(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["PhotoType"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON GET 模特兒風格
    func parse_Mstyle(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["ModelRole"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON GET 攝影師電話
    func parse_Pphone(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["Phone"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON GET 模特兒電話
    func parse_Mphone(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["Phone"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON GET 攝影師地點
    func parse_Plocation(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["Location"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析JSON GET 模特兒地點
    func parse_Mlocation(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let nameResult = showNamwDict["Location"] as! String
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //GET 全部Id
    func parse_Id(data: Data) -> Array<Any>{
        var resultArray:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for showNamwDict in resArray{
                
                let strname = showNamwDict["UserId"] as! Int
                let nameResult = String(strname) //取到的id轉為字串
                resultArray.append(nameResult)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //解析 作品照片
    func parse_Product(data: Data) -> Array<Any>{
        var resultArray:[String] = []

        /////解析JSON
        do{
            
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
                print("====111===",resDict)
            
                let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
                
                for showNamwDict in resArray{
                    let nameResult = showNamwDict["Path"] as! String
                    resultArray.append(nameResult)
                }
 
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return resultArray
    }
    
    //會員頁面 大頭照上傳
    func postPhotoToDatabase(uploaderId uploaderId:String,firebaseURL firebaseURL:String) -> String{
        
        let postdata:[String: Any] = ["UploaderUid":uploaderId,"Path":firebaseURL] //注意：型別 與 欄位名稱 是否與資料庫一致
        
        let url = URL(string: "http://Testpmtobe-env.cvxrvfa7jm.ap-northeast-1.elasticbeanstalk.com/api/UploadImageAPP") //用我寫的api
        
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config, delegate: nil, delegateQueue: nil)
        var request = URLRequest(url: url!)
        
        request.httpMethod = "POST"
        request.addValue("application/json; charset=UTF-8", forHTTPHeaderField: "Content-Type")
        
        guard let httpbody = try? JSONSerialization.data(withJSONObject: postdata, options: []) else {return firebaseURL}
        request.httpBody = httpbody
        
        let dataTask = session.dataTask(with: request, completionHandler: {(data: Data?, response: URLResponse?, error: Error?) -> Void in
            
            if let response = response{
                print("<===================>這是URLResponse：")
                print(response)
            }
            if let data = data{
                do{
                    let json = try JSONSerialization.jsonObject(with: data, options: []) as! [String:Any]
                    print("<===================>這是json：")
                    print(json)
                    
                }catch{
                    print("<===================>這是error：")
                    print(error)
                    
                }
            }
        })
        dataTask.resume()
        return firebaseURL
    }
    
    
    
    
    
    /////////////////////////////////Spot api begin///////////////////////////////////////////
    
    func parseAllSpotName(data: Data) -> Array<Any>{
        var arraySpotName:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for SpotDict in resArray{
                
                let theName = SpotDict["Name"] as! String
                
                arraySpotName.append(theName)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return arraySpotName
    }
    
    
    //parse json to get all spot info
    func parseAllSpotGUID(data: Data) -> Array<Any>{
        var arraySpotGUID:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for SpotDict in resArray{
                
                let theGuid = SpotDict["GUID"] as! String
                
                arraySpotGUID.append(theGuid)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return arraySpotGUID
    }
    
    //parse json to get all spot info
    func parseAllSpotPosX(data: Data) -> Array<Any>{
        var arraySpotPosX:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for SpotDict in resArray{
                
                let thePosX = SpotDict["PosX"] as! Double
                let thestrPosX=String(format: "%f", thePosX)
                arraySpotPosX.append(thestrPosX)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return arraySpotPosX
    }
    
    //parse json to get all spot info
    func parseAllSpotPosY(data: Data) -> Array<Any>{
        var arraySpotPosY:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for SpotDict in resArray{
                
                let thePosY = SpotDict["PosY"] as! Double
                let thestrPosY=String(format: "%f", thePosY)
                arraySpotPosY.append(thestrPosY)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return arraySpotPosY
    }
    
    func parseAllSpotAddress(data: Data) -> Array<Any>{
        var arraySpotAddress:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for SpotDict in resArray{
                
                let theAddress = SpotDict["Address"] as! String
                
                arraySpotAddress.append(theAddress)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return arraySpotAddress
    }
    
    func parseAllSpotDescription(data: Data) -> Array<Any>{
        var arraySpotDescription:[String] = []
        
        print(data)
        /////解析JSON
        do{
            let resDict: [String: Any] = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves) as! [String:Any]
            
            let resArray = resDict["data"] as! [[String:Any]]//拿到data的所有陣列值
            
            for SpotDict in resArray{
                
                let theDescription = SpotDict["Description"] as! String
                
                arraySpotDescription.append(theDescription)
            }
        }catch{
            print("解析出現錯誤:\(String(describing: error.localizedDescription))") //error是do catch丟出的 不是回傳進來的
        }
        
        return arraySpotDescription
    }
    
    /////////////////////////////////////Spot APi End///////////////////////////////////////////////
    
    
    
}














