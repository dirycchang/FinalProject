//
//  MemberViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/28.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn
import FirebaseAuth

class MemberViewController: UIViewController {

    //登出
    @IBAction func signOut(_ sender: Any) {
        do {
            try Auth.auth().signOut()
            GIDSignIn.sharedInstance().signOut()
            let alertView = UIAlertController.init(title: "成功登出", message: "", preferredStyle: .alert)
            alertView.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
            self.present(alertView, animated: true, completion: nil)
            
        } catch  {
            print(error.localizedDescription)
        }
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

       
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
