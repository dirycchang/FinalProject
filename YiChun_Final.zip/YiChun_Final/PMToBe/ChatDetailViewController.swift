//
//  ChatDetailViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/26.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit

class ChatDetailViewController: UIViewController {
    
    @IBOutlet weak var myName: UILabel!
    
    var infofromViewOne:String? //宣告變數(String optional)來接收從ChatMenuTableViewController傳來的訊息

    override func viewDidLoad() {
        super.viewDidLoad()
        
        myName.text = infofromViewOne //將所選的名稱由label顯示

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
