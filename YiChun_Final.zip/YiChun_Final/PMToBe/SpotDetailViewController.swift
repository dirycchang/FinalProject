//
//  SpotDetailViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/25.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation //取得使用者位置函式庫

class SpotDetailViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var mySpotName: UILabel!
    
    var infofromViewOne:String? //宣告變數(String optional)來接收從SharedSpotTableViewController傳來的訊息
    
    @IBOutlet weak var map: MKMapView!
    
    var locationManager : CLLocationManager? //宣告optional CLLocationManager型別的變數 可存放使用者位置（一開始是nil）
    
    override func viewDidLoad() {
        super.viewDidLoad()

        mySpotName.text = infofromViewOne //將所選的名稱由label顯示
        
        locationManager = CLLocationManager() //建立CLLocationManager 存進locationManager屬性中
        locationManager?.requestWhenInUseAuthorization() //請求使用者授權 以拿到使用者位置的資訊
        
        //追蹤使用者位置
        locationManager?.delegate = self  //把self（即viewController）指定給locationManager?.delegate 故每次更新時locationManager會問delegate屬性
        locationManager?.desiredAccuracy = kCLLocationAccuracyBest //設定精準度：kCLLocationAccuracyBest(最高)、kCLLocationAccuracyKilometer(一公里內)...
        locationManager?.activityType = .automotiveNavigation //活動模式：.automotiveNavigation(導航模式)
        locationManager?.startUpdatingLocation()  //每次手機移動（更新地點資訊）時觸發協定方法
        
        if let coordinate = locationManager?.location?.coordinate{ //用locationManager?.location?.coordinate來得知座標 若有值就繼續執行body
            
            let xScale:CLLocationDegrees = 0.005
            let yScale:CLLocationDegrees = 0.005
            let span :MKCoordinateSpan = MKCoordinateSpan(latitudeDelta: yScale, longitudeDelta: xScale)
            let region = MKCoordinateRegion(center: coordinate, span: span)
            map.setRegion(region, animated: true)
        }
        
        map.userTrackingMode = .followWithHeading //none(不依據位置更新)、follow(隨使用者做更新)、followWithHeading（讓使用者位置保持在中心 且 若人轉向 地圖也會跟者轉）
        
    }

    //每次手機移動（更新地點資訊）時觸發協定方法：didUpdateLocations （參數 location 是陣列）
    func locationManager(_ manager: CLLocationManager, didUpdateLocations location:[CLLocation]) {
        print("----------------------------")
        print(location[0].coordinate.latitude)
        print(location[0].coordinate.longitude)
    }
    
    //只要長按畫面  就會執行此方法)
    @IBAction func addMeAnnovation(_ sender: UILongPressGestureRecognizer) {
        let touchPoint = sender.location(in: map) //把手指觸碰到map中的location回傳 存進常數中
        
        //用map.convert()把觸控到的點轉成地圖上的座標  再存進常數中（可再標示其型別：CLLocationCoordinate2D）
        let touchCoordinate:CLLocationCoordinate2D = map.convert(touchPoint, toCoordinateFrom: map)
        
        
        //加入大頭針
        let annotation = MKPointAnnotation() //產生大頭針
        annotation.coordinate = touchCoordinate //將大頭針的座標設為touchCoordinate的座標
        annotation.title = "Seleceted New Place"
        annotation.subtitle = "One day I'll be here!"
        map.addAnnotation(annotation) //將大頭針加進地圖中
        
    }
    
    
    //若離開畫面 就執行viewDidAppear
    override func viewDidAppear(_ animated: Bool) {
        locationManager?.stopUpdatingLocation()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
