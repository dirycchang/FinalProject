//
//  ViewController.swift
//  PMToBe
//
//  Created by Yi Chun on 2018/8/25.
//  Copyright © 2018年 YiChun. All rights reserved.
//

import UIKit
import Firebase
import FirebaseDatabase
import GoogleSignIn
import FirebaseAuth

class ViewController: UIViewController,GIDSignInDelegate,GIDSignInUIDelegate {
    
    
    //GOOGLE登入
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error!) {
        if error == nil {
            if let authentication = user.authentication{
                let authCredential = GoogleAuthProvider.credential(withIDToken: authentication.idToken, accessToken: authentication.accessToken)
                //登入firebase
                Auth.auth().signIn(with: authCredential, completion: { (firebaseUser, error) in
                    if error == nil{
                        
                        
                        
                        let alertView = UIAlertController.init(title: "成功登入", message: "", preferredStyle: .alert)
                        alertView.addAction(UIAlertAction.init(title: "OK", style: .default, handler: nil))
                        self.present(alertView, animated: true, completion: nil)
                        
                        // 呈現主視圖
                        if let viewController = self.storyboard?.instantiateViewController(withIdentifier: "MainView") {
                            UIApplication.shared.keyWindow?.rootViewController = viewController
                            self.dismiss(animated: true, completion: nil)
                        }
                        
                    }
                })
            }
        }else{
            print(error.localizedDescription)
        }
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        print("=======UserDefault路徑")
//        print(NSHomeDirectory())
        
        let path:[String] = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.libraryDirectory, FileManager.SearchPathDomainMask.userDomainMask, true) //false：相對路徑 true：完整路徑
        
        //技巧：JSON拉回來的圖片要存到cashes 顯示TableView （***聽102-10/04 10:20~10:21）
        
        //取得沙盒的陣列元素
        let dirPath:String = path[0] //因path是集合 且只有一個  故用path[0]一定會取得
        
        print("sandbox folder:\(dirPath)")
        
        GIDSignIn.sharedInstance().clientID = FirebaseApp.app()?.options.clientID
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        
//        //可取得Google登入的資料
//        let user = Auth.auth().currentUser
//        let Email = user?.email
//        let Name = user?.displayName
//        let uid = user?.uid
//        let providerID = user?.providerID
//        let photoURL = user?.photoURL
//        print("===========================")
//        print(Email) //認證信箱
//        print(Name) //Google上的名稱
//        print(uid) //Firebase認證的使用者id
//        print(providerID) //Firebase
//        print(photoURL) //可取得Google大頭照
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

