//
//  SpotDetailController.swift
//  PMToBe
//
//  Created by Yi Hwei Huang on 2018/10/11.
//  Copyright © 2018 YiChun. All rights reserved.
//

import UIKit
import MapKit
import CoreLocation

class SpotDetailController: UIViewController {

    
    @IBOutlet weak var detailMapView: MKMapView!
    @IBOutlet weak var spotImage: UIImageView!
    @IBOutlet weak var lblSpotName: UILabel!
    @IBOutlet weak var lblSpotAddress: UILabel!
    @IBOutlet weak var lblSpotDescri: UILabel!
    
    var strAddress:String=""
    var strDescription:String=""
    var strName:String=""
    var strLat:String=""
    var strLon:String=""
    var strGUID:String=""
    var mapScaleMeter:Double=1000.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
       lblSpotName.text=strName
       lblSpotDescri.text=strDescription
       lblSpotAddress.text=strAddress
       
        self.addLandmark()
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
        
    }
    
    func addLandmark(){
        let Lat:Double=Double(strLat)!
        let Lon:Double=Double(strLon)!
        
        var myAutoFlag:CLLocationCoordinate2D=CLLocationCoordinate2D()
        myAutoFlag.longitude=Lon
        myAutoFlag.latitude=Lat
        print(myAutoFlag.latitude,"====myAutoFlag.latitude==")
        print(myAutoFlag.longitude,"=======myAutoFlag.longitude======")
        
        
        let myAutoFlagAnno:MKPointAnnotation = MKPointAnnotation()
        myAutoFlagAnno.coordinate=myAutoFlag
        myAutoFlagAnno.title=lblSpotName.text
        print(myAutoFlagAnno.title!,"=====myAutoFlagAnno.title=======")
        
        
        self.detailMapView.addAnnotation(myAutoFlagAnno)
        
        self.mapScaleMeter *= 1.5
        let region:MKCoordinateRegion=MKCoordinateRegionMakeWithDistance(myAutoFlagAnno.coordinate, self.mapScaleMeter,self.mapScaleMeter )
        self.detailMapView.setRegion(region, animated: false)

        
    }
    
    
    
   

}
